'use strict';
const assert=require('node:assert/strict');
const P=require('./phase-conjecture.js'),R=require('./real-model.js');
const close=(x,y)=>assert.ok(Math.abs(x-y)<1e-12*Math.max(1,Math.abs(y)),`${x} != ${y}`);
// Analytic anchors: the Gaussian fractional scale, its critical logarithm,
// and the requested q=1 observable. These also check the inverse log sign.
close(R.candidateNormalization(64,1,2.25).factor,1/64**1.25);
close(R.candidateNormalization(64,1,2.5).factor,Math.log(64)/512);
close(R.candidateNormalization(64,2,3).factor,Math.sqrt(Math.log(64))/512);
close(R.candidateNormalization(64,2,4).factor,1/512);
close(R.candidateNormalization(64,2,1.5).factor,1/64**.75);
close(R.candidateNormalization(64,1,2).factor,1/(64*Math.sqrt(Math.log(64))));
close(R.candidateNormalization(64,1,2.25,3).factor,3/64**1.25);
close(R.candidateNormalization(64,2,2.25,9).factor,3/64**1.125);
// The website and the sampler must use the same normalization across regimes.
for(const q of [.5,1,1.5,2])for(const alpha of [1.5,2,2+q/4,2+q/2,3.5]){
  const p=P.prediction(q,alpha),s=R.candidateScaling(q,alpha);
  close(p.power,s.H);close(p.logPower,s.logPower);
  if(q===2)assert.notEqual(p.law,'non-gaussian');
}
assert.equal(P.prediction(1,2.25).measured,true);
assert.equal(P.prediction(1,2.5).measured,false);
assert.throws(()=>P.prediction(3,2.25),RangeError);
console.log(JSON.stringify({passed:true,checks:'Gaussian and q=1 normalization anchors; logarithm signs; exact beta scaling; website/sampler agreement; data scope'}));
