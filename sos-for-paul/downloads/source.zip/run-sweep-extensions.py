"""Additional reflection-cluster runs, retaining every original Metropolis run."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,json,subprocess,time
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'experiments/parameter-sweep/extended';OUT.mkdir(exist_ok=True)
parser=argparse.ArgumentParser();parser.add_argument('--workers',type=int,default=6);parser.add_argument('--rough',action='store_true');parser.add_argument('--rough-high',action='store_true');parser.add_argument('--precision',action='store_true');args=parser.parse_args()
original=json.loads((OUT.parent/'plan-32-64-128-256-512.json').read_text())
if args.precision:
 points=[p for p in original['points'] if p['q']==1.5 and p['regime']=='rough-mid'];sizes=[512]
elif args.rough_high:
 points=[p for p in original['points'] if p['q']<2 and p['regime']=='rough-high'];sizes=[256,512]
elif args.rough:
 points=[p for p in original['points'] if p['q'] in [.5,1.5] and p['regime']=='rough-mid'];sizes=[1024]
else:
 points=[p for p in original['points'] if (p['q']<2 and p['regime'] in ['upper-critical','near-diffusive','diffusive']) or (p['q']==2 and p['regime']=='diffusive')];sizes=[128,256,512]
plan={'sampler':'cluster-sos.cpp','reason':'Extend runs identified by ESS/Rhat or insufficient fourth-moment precision; retain all original runs for comparison.','points':points,'sizes':sizes,'replicas':3,'samples':40000 if args.precision else 8000,'burn':12000,'thin':3,'selection':'Regime-wide mixing extensions; the q=1.5 rough-mid precision extension follows an inconclusive kurtosis interval and is explicitly exploratory.'}
tag='precision' if args.precision else 'rough-high' if args.rough_high else 'rough' if args.rough else 'cluster'
planfile=OUT.parent/(tag+'-extension-plan.json');planfile.write_text(json.dumps(plan,indent=2))
jobs=[(p,n,r) for n in sizes for p in points for r in range(3)];start=time.time()
def run(job):
 p,n,r=job;folder=OUT/p['key'];folder.mkdir(exist_ok=True);stem=folder/f'n{n}-r{r}';meta=stem.with_suffix('.meta.json')
 if meta.exists():return {'cached':True,'key':p['key'],'N':n,'replica':r}
 seed=1083009171+int(p['q']*100)*10000019+int(round(p['alpha']*1000))*1009+n*9176+r*104729
 with stem.with_suffix('.log').open('w') as log:subprocess.run([str(ROOT/'.verification/cluster-sos'),str(n),str(p['q']),str(p['alpha']),str(plan['samples']),str(plan['burn']),str(plan['thin']),str(seed),str(r),str(stem)],stdout=log,stderr=subprocess.STDOUT,check=True)
 data=json.loads(meta.read_text());data['sampler']='cluster';data['clusterMovesPerSweep']=2;meta.write_text(json.dumps(data,separators=(',',':'))+'\n')
 return {'key':p['key'],'N':n,'replica':r,'seconds':round(data['seconds'],1),'qMeanEnergy':round(data['q']*data['meanBetaEnergyPerDimension'],5)}
with ThreadPoolExecutor(max_workers=args.workers) as pool:
 for i,f in enumerate(as_completed([pool.submit(run,j) for j in jobs]),1):
  result=f.result();result.update(done=i,total=len(jobs),wallSeconds=round(time.time()-start,1));print(json.dumps(result),flush=True)
print(json.dumps({'complete':True,'chains':len(jobs),'seconds':round(time.time()-start,1)}),flush=True)
