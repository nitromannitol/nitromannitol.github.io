# Precise conjectures for the real-valued long-range q-SOS model

## Current predictions from the data

**At q = 1, α = 2.25, our current prediction is a non-Gaussian scaling limit with H = 1/4.** Thus, for smooth compactly supported f on D = (−1,1), we conjecture

\[
\beta n^{-5/4}\sum_{i=-n}^{n}f(i/n)\phi(i)
\ \Longrightarrow\ \langle\Phi_{1,2.25},f\rangle,
\qquad \Phi_{1,2.25}\text{ non-Gaussian}.
\]

We predict that the even-bump excess kurtosis remains strictly positive as n grows. This would exclude fractional Brownian motion, which is Gaussian. The original n = 512–2048 fit gives H = 0.242; the independently seeded sweep gives 0.241. The original normalized variances are 0.02459, 0.02468 and 0.02407, while the corresponding kurtoses are 0.260, 0.302 and 0.442. This is our best-supported nonlinear scaling prediction.

The **28-pair sweep** changes how much of the broader diagram we should endorse. Here are the current predictions, with aₙ denoting the scale of the smooth spatial average, so that the pairing is β¹/ᑫ(naₙ)⁻¹Σfφ.

| Parameters | Current prediction | What the data say |
|---|---|---|
| Rough interval, 2 < α < 2 + q/2, 0 < q < 2 | **Non-Gaussian field; working power aₙ = n^((α−2)/q).** | Non-Gaussianity is favored at both tested rough points for each q = 0.5, 1, 1.5. The H = 1/4 power fits well at (0.5, 2.125) and (1, 2.25); the powers remain less secure closer to the proposed upper boundary. Extension to all parameters is a conjecture. |
| α = 3.5, q = 0.5, 1, 1.5 | **Gaussian Brownian bridge σ(q,3.5)B_D; aₙ = √n.** | H fits are 0.496, 0.496, 0.492. The three even-bump kurtosis intervals include zero, and covariance ratios approach the bridge values. This favors the far-diffusive prediction. |
| α = 1.75, q = 0.5, 1, 1.5 | **Tentative Gaussian fractional generalized field σ(q,1.75)G₁․₇₅; aₙ = n⁻¹/⁸.** | Kurtosis decreases across the size range at q = 0.5 and 1, but variance powers and covariance ratios still drift. The broader 1 < α < 2 Gaussian prediction has weaker support. |
| α = 2 or near αc(q) = 2 + q/2, q < 2 | **No limiting law or precise logarithmic correction selected by the present data.** | The original Gaussian critical limits and log powers remain provisional hypotheses. At (0.5, 2.4), already above the proposed αc = 2.25, κ(f) = 0.323 [0.203, 0.436] at n = 512. We cannot yet choose between slow convergence to a Gaussian limit and a different transition picture. |
| q = 2, all α > 1 | **Gaussian exactly.** Fractional for 1 < α < 3; Brownian bridge for α ≥ 3, with a logarithm at α = 3. | This is the quadratic benchmark, independent of the empirical normality tests. Its constants and scales are given below. |

**A further prediction across q:** along α = 2 + q/4, where the proposed H stays 1/4, non-Gaussianity should weaken as q approaches 2. At n = 512, the even-bump kurtoses are 0.531, 0.340 and 0.113 for q = 0.5, 1 and 1.5; q = 2 is exactly Gaussian. We conjecture a non-Gaussian family for q < 2 that approaches the quadratic Gaussian field as q ↑ 2. These three nonlinear points suggest the trend; they do not establish monotonicity for every observable.

**What changed:** we retain the non-Gaussian rough-field picture and the Brownian picture at large α. We no longer present the boundary αc = 2 + q/2 or either nonlinear critical logarithm as conclusions suggested securely by the sweep. For example, at α = 2 + 0.4q the effective H values are 0.291, 0.332 and 0.344, below the proposed 0.4; the q = 1.5 rough-mid fit is 0.222 rather than 0.25. We retain those powers as working guesses, not as measured asymptotic exponents. The data do not warrant replacing them with the finite-size fits.

The non-Gaussian field's **full joint law remains unidentified**. The Brownian-cutoff construction later on this page is a separate, untested candidate; a match of exponents and a few fourth moments cannot select it. The Gaussian amplitudes σ are deterministic and not yet identified at nonlinear q. Changing β only multiplies heights by β⁻¹/ᑫ, exactly at every finite size.

These are predictions from 4,344,000 new recordings, plus the earlier 456,000-recording study through n = 2048. All quoted intervals describe Monte Carlo uncertainty, not finite-size bias. Open the [interactive sweep](parameter-sweep.html) for every size and parameter pair, or the [numerical report](sweep-report.md) for the evidence and diagnostics.

## Model and normalization

Let D = (−1,1). At sites −n,…,n, sample real heights with density proportional to

\[
\exp\!\left[-\beta\sum_{i\ne j\in\mathbb Z}
\frac{|\phi(i)-\phi(j)|^q}{|i-j|^\alpha}\right]
\prod_{i=-n}^n d\phi(i),
\qquad \phi=0\text{ on the entire exterior}.
\]

The sum is over ordered pairs. The proposed diagram covers **0 < q ≤ 2, α > 1, β > 0**. It does not assert anything about integer heights or q > 2.

For every finite collection of test functions f₁,…,fₖ ∈ C∞c(D), conjecture joint convergence of

\[
Y_n(f)=\frac{\beta^{1/q}}{n a_n}\sum_{i=-n}^n f(i/n)\phi(i)
\quad\Longrightarrow\quad \langle\Phi,f\rangle.
\]

The β dependence is exact at every n: φβ has the same law as β⁻¹/ᑫφ₁. Consequently a change of positive β cannot change the phase for this real homogeneous model. The factor n⁻¹ is the Riemann-sum factor.

Define B_D to be the standard Brownian bridge on (−1,1), with covariance

\[
G_D(s,t)=\min(s+1,t+1)-\frac{(s+1)(t+1)}2.
\]

For 1 < α < 3, let Gα be the centered Gaussian random distribution with covariance (4Lα)⁻¹, where

\[
L_\alpha u(x)=\operatorname{PV}\!\int_{\mathbb R}
\frac{u(x)-u(y)}{|x-y|^\alpha}\,dy,
\qquad u=0\text{ on }D^c.
\]

This specifies the restricted operator with zero exterior, including its constant. It is not the spectral fractional power of the interval Laplacian. For α > 2 the field has continuous versions; at and below 2 the formulation is distributional.

## Original phase diagram: retained hypotheses, with revised confidence

This is the formula-level hypothesis tested by the sweep. Its rough and far-diffusive pictures remain our working predictions. Its exact nonlinear critical rows and transition boundary remain unselected by the data, as stated above. The pre-sweep version is preserved with the downloadable run plans.

Set αc(q) = 2 + q/2. For 0 < q < 2:

| Range | Smooth-average scale aₙ | Conjectured limiting law |
|---|---|---|
| 1 < α < 2 | n^((α−2)/2) | σ(q,α) Gα |
| α = 2 | (log n)^(1/q−1/2) | σ(q,2) G₂ |
| 2 < α < 2 + q/2 | n^((α−2)/q) | Q(q,α), defined by the cutoff prescription below |
| α = 2 + q/2 | √n / (log n)^(1/q) | σ(q) B_D |
| α > 2 + q/2 | √n | σ(q,α) B_D |

Every σ in this table is conjectured to be a **deterministic, finite, strictly positive constant**. The current runs measure finite-size variances and amplitude-free covariance ratios; they do not identify the limiting σ at nonlinear q, and no closed formula is asserted. The claim specifies the field law up to that deterministic amplitude in the Gaussian regimes. Q(q,α) has a proposed full normalization from its defining construction.

In the rough interval, conjecture that Q(q,α) is non-Gaussian for every q < 2, and that linearly interpolated fields converge in Cγ on compact subintervals for γ < H = (α−2)/q. In the Brownian regimes, the corresponding proposed regularity is γ < 1/2. This path-level convergence and tightness are additional claims beyond the measured smooth observables.

The rows α ≤ 2 concern **smooth averages, not the standard deviation of a single height**. A compatible, more speculative point-height prediction is bounded variance for α < 2 and Var φ(0) of order β⁻²/ᑫ(log n)²/ᑫ at α = 2. For example, at q = 1, α = 2, this predicts point-height RMS of order log n but smooth-average RMS of order √log n. The new sweep includes both α = 1.75 and α = 2 at all four q values. Its effective nonlinear log powers differ from the proposed asymptotic powers over the simulated window; the [critical-point comparison](sweep-report.md) explains this limitation.

## An untested candidate for the full non-Gaussian law Q(q,α)

“A non-Gaussian field with exponent H” or “a random covariance mixture” does not identify a probability law. Here is a particular construction to conjecture and then test. Its cutoff removal, universality and agreement with the lattice are all unproved and untested here.

Fix 0 < q < 2 and 2 < α < 2 + q/2, put H = (α−2)/q, and choose any fixed η > 0. For ε > 0, define the continuous Gaussian reference

\[
U_\varepsilon=\eta\varepsilon^{H-1/2}B_D,
\]

extended by zero outside D. For a continuous zero-boundary path u, define the finite-cutoff action

\[
\mathcal E_\varepsilon(u)=
\iint_{\substack{(x,y)\in\mathbb R^2\\|x-y|>\varepsilon}}
\frac{|u(x)-u(y)|^q}{|x-y|^\alpha}\,dx\,dy.
\]

The integral includes the whole zero exterior and uses ordered pairs. For every ε > 0 it is finite almost surely under the Gaussian reference. Thus

\[
\nu_\varepsilon^{(\eta)}(du)=
\frac{e^{-\mathcal E_\varepsilon(u)}}{
\mathbb E e^{-\mathcal E_\varepsilon(U_\varepsilon)}}
\operatorname{Law}(U_\varepsilon)(du)
\]

is an actual probability measure; there is no appeal to infinite-dimensional Lebesgue measure.

**Constructive conjecture.** The measures νε⁽η⁾ converge as ε ↓ 0 to a nondegenerate law Q(q,α), independently of η, and the lattice model under the normalization above converges to this same law. In particular its characteristic functional would be

\[
\boxed{\quad
\chi_{q,\alpha}(f)=
\lim_{\varepsilon\downarrow0}
\frac{\mathbb E\exp\{i\langle U_\varepsilon,f\rangle-
\mathcal E_\varepsilon(U_\varepsilon)\}}
{\mathbb E\exp\{-\mathcal E_\varepsilon(U_\varepsilon)\}}.
\quad}
\]

Taking f = Σtⱼfⱼ specifies each proposed finite-dimensional joint law. This prescription has no fitted covariance distribution or marginal-shape parameter. Its existence and the equality with the lattice limit are substantive parts of the conjecture, not definitions that are already known to hold.

The growing reference diffusivity η²ε²ᴴ⁻¹ represents microscopic variance viewed under a subdiffusive spatial rescaling. Its Gaussian local stiffness has coefficient proportional to ε¹⁻²ᴴ, which vanishes at macroscopic scale. Independence of η is a proposed irrelevance of this local regularization; it needs a separate numerical or mathematical test. At q = 2 the quadratic prescription reduces to the Gaussian operator above, providing a consistency check on the convention.

On a dilated domain LD, the construction predicts Qᴸᴰ(Lt) equal in law to LᴴQᴰ(t). This is a statement about a family of domains with matching zero exteriors. It does not claim stationary increments inside the fixed interval, where the boundary matters.

The cutoff cannot simply be discarded inside the action. In particular the unregularized |u(x)−u(y)|/|x−y|²·²⁵ integral can diverge even on nonconstant smooth paths. Writing exp(−E(u)) Du without a prescription would not identify a law.

For 0 < q ≤ 2, the finite-cutoff interaction factors admit positive Gaussian mixtures. Combined with the Gaussian reference, this motivates a random-covariance interpretation of Q. It does **not** imply that one independent scalar amplitude times a fixed Gaussian field describes the limit. The explicit cutoff prescription, rather than that broad description, is the proposed full candidate.

## Exact quadratic anchors and boundary conventions

For q = 2 the model is Gaussian already at finite n. Under the table's normalizations:

\[
\Phi=\begin{cases}
G_\alpha,&1<\alpha<3,\\
\tfrac12 B_D,&\alpha=3,\\
[4\zeta(\alpha-2)]^{-1/2}B_D,&\alpha>3.
\end{cases}
\]

These constants follow from the ordered-pair energy. The Fourier symbol of the lattice L is 2Σr≥1(1−cos kr)/rα. At α = 3 its leading small-k term is k²log(1/|k|); at α > 3 it is ζ(α−2)k². The finite Gaussian precision is 4βL.

On the whole line, the pinned Gaussian field for 2 < α < 3 has the fractional Brownian exponent H = (α−2)/2. With our full zero exterior, the correct limiting object is the restricted Dirichlet fractional Gaussian field. Merely conditioning two endpoint values of an unconditioned fBm does not specify that same exterior condition.

As an additional amplitude check, in the nearest-neighbor limit α → ∞ the increment density is proportional to exp(−2|z|q) at β = 1. Its variance, and hence the squared Brownian amplitude, is

\[
\sigma(q,\infty)^2=2^{-2/q}\frac{\Gamma(3/q)}{\Gamma(1/q)}.
\]

This gives σ(1,∞)² = 1/2 and σ(2,∞)² = 1/4.

## Why these exponents and logarithms are plausible

A macroscopic interaction under φ(nt) ≈ nᴴΦ(t) scales as n²⁻ᵅ⁺ᑫᴴ. Requiring a finite nonzero coefficient gives H = (α−2)/q. This balances the large-scale interaction; it is not a proof that microscopic terms are irrelevant.

Under Brownian scaling H = 1/2 the same coefficient is n²⁻ᵅ⁺ᑫ/². It decreases for α > 2 + q/2, suggesting a Gaussian diffusive limit, and is marginal at equality. A self-consistent quadratic-response heuristic predicts a running stiffness of order (log n)²/ᑫ at that equality, hence height scale √n/(log n)¹/ᑫ. The exact q = 2 logarithm agrees with this expression.

For α < 2, the more speculative picture is a localized microscopic field with a Gaussian long-wavelength response whose fractional exponent is (α−2)/2, independent of q. At α = 2, a self-consistent logarithmic response suggests point variance (log n)²/ᑫ and smooth-average variance (log n)²/ᑫ⁻¹. This is the origin of the separate logarithmic row. The new sweep tests this prediction but does not resolve its asymptotic validity, especially at q = 0.5. These critical claims should be read as hypotheses rather than measured laws.

## The original q = 1, α = 2.25 study

At q = 1, α = 2.25 the conjectured scale is aₙ = n¹/⁴, so the smooth pairing is β n⁻⁵/⁴Σfφ. The largest saved runs give:

| n | Recordings | Var(n⁻⁵/⁴Σfφ) | Excess kurtosis | Approximate 95% block interval |
|---|---:|---:|---:|---|
| 512 | 60,000 | 0.02459 | 0.260 | [0.179, 0.346] |
| 1024 | 60,000 | 0.02468 | 0.302 | [0.164, 0.453] |
| 2048 | 24,000 | 0.02407 | 0.442 | [0.261, 0.625] |

The variance fit gives H ≈ 0.242. At n = 1024, the even-minus-odd excess-kurtosis interval is [0.052, 0.377], and a mixed fourth-cumulant identity also disagrees with the simple model A times G, with A independent of G. At n = 2048 that refinement is inconclusive because its intervals are wider. There are about 514 effective even-bump samples at n = 2048, despite 24,000 recorded configurations.

This supports the exponent and persistent non-Gaussianity as working guesses. It does not select the Brownian cutoff candidate among all non-Gaussian fields. In particular, generalized-normal or variance-gamma fits to one observable cannot establish the joint limiting law.

The new sweep tests fourth cumulants below, at and above the proposed crossover for three nonlinear q values. The remaining discriminating experiments are larger critical boxes and a direct comparison with the cutoff construction at different η. A drift to zero kurtosis at q = 1, α = 2.25, or dependence of the proposed cutoff limit on η, would contradict the corresponding parts of the conjecture.

See [gaussianity.html](gaussianity.html) for the interactive phase diagram and original saved data, [scaling-limit-guess.md](scaling-limit-guess.md) for the original sampling details, and [sweep-report.md](sweep-report.md) for the broader experiment. All 456,000 original recordings are preserved, including the earlier small boxes; 264,000 of those are from the compiled continuation. The new parameter sweep is archived separately.
