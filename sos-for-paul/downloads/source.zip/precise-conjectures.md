# Precise conjectures for the real-valued long-range q-SOS model

These are the original mathematical hypotheses, now compared against a **28-pair parameter sweep** at q = 0.5, 1, 1.5 and 2, with n = 32, 64, 128, 256 and 512. The earlier q = 1, α = 2.25 study extends to n = 2048. The [interactive sweep](parameter-sweep.html) shows the measurements, and the [updated assessment](sweep-report.md) separates supported features from unresolved predictions.

The new rough-regime points favor non-Gaussianity beyond the original pair. Well above the proposed crossover, the data favor Brownian behavior. **The nonlinear critical logarithms and the crossover location remain unresolved:** even some points above the proposed boundary retain clear non-Gaussian finite-size effects. The particular cutoff construction below is stronger than what these lattice data identify, and has not itself been simulated. The pre-sweep statement is preserved in the downloadable run plans.

## Model and normalization

Let D = (−1,1). At sites −n,…,n, sample real heights with density proportional to

\[
\exp\!\left[-\beta\sum_{i\ne j\in\mathbb Z}
\frac{|\phi(i)-\phi(j)|^q}{|i-j|^\alpha}\right]
\prod_{i=-n}^n d\phi(i),
\qquad \phi=0\text{ on the entire exterior}.
\]

The sum is over ordered pairs. The proposed diagram covers **0 < q ≤ 2, α > 1, β > 0**. It does not assert anything about integer heights or q > 2.

For every finite collection of test functions f₁,…,fₖ ∈ C∞c(D), conjecture joint convergence of

\[
Y_n(f)=\frac{\beta^{1/q}}{n a_n}\sum_{i=-n}^n f(i/n)\phi(i)
\quad\Longrightarrow\quad \langle\Phi,f\rangle.
\]

The β dependence is exact at every n: φβ has the same law as β⁻¹/ᑫφ₁. Consequently a change of positive β cannot change the phase for this real homogeneous model. The factor n⁻¹ is the Riemann-sum factor.

Define B_D to be the standard Brownian bridge on (−1,1), with covariance

\[
G_D(s,t)=\min(s+1,t+1)-\frac{(s+1)(t+1)}2.
\]

For 1 < α < 3, let Gα be the centered Gaussian random distribution with covariance (4Lα)⁻¹, where

\[
L_\alpha u(x)=\operatorname{PV}\!\int_{\mathbb R}
\frac{u(x)-u(y)}{|x-y|^\alpha}\,dy,
\qquad u=0\text{ on }D^c.
\]

This specifies the restricted operator with zero exterior, including its constant. It is not the spectral fractional power of the interval Laplacian. For α > 2 the field has continuous versions; at and below 2 the formulation is distributional.

## The proposed phase diagram

Set αc(q) = 2 + q/2. For 0 < q < 2:

| Range | Smooth-average scale aₙ | Conjectured limiting law |
|---|---|---|
| 1 < α < 2 | n^((α−2)/2) | σ(q,α) Gα |
| α = 2 | (log n)^(1/q−1/2) | σ(q,2) G₂ |
| 2 < α < 2 + q/2 | n^((α−2)/q) | Q(q,α), defined by the cutoff prescription below |
| α = 2 + q/2 | √n / (log n)^(1/q) | σ(q) B_D |
| α > 2 + q/2 | √n | σ(q,α) B_D |

Every σ in this table is conjectured to be a **deterministic, finite, strictly positive constant**. The current runs measure finite-size variances and amplitude-free covariance ratios; they do not identify the limiting σ at nonlinear q, and no closed formula is asserted. The claim specifies the field law up to that deterministic amplitude in the Gaussian regimes. Q(q,α) has a proposed full normalization from its defining construction.

In the rough interval, conjecture that Q(q,α) is non-Gaussian for every q < 2, and that linearly interpolated fields converge in Cγ on compact subintervals for γ < H = (α−2)/q. In the Brownian regimes, the corresponding proposed regularity is γ < 1/2. This path-level convergence and tightness are additional claims beyond the measured smooth observables.

The rows α ≤ 2 concern **smooth averages, not the standard deviation of a single height**. A compatible, more speculative point-height prediction is bounded variance for α < 2 and Var φ(0) of order β⁻²/ᑫ(log n)²/ᑫ at α = 2. For example, at q = 1, α = 2, this predicts point-height RMS of order log n but smooth-average RMS of order √log n. The new sweep includes both α = 1.75 and α = 2 at all four q values. Its effective nonlinear log powers differ from the proposed asymptotic powers over the simulated window; the [critical-point comparison](sweep-report.md) explains this limitation.

## A precise candidate for Q(q,α)

“A non-Gaussian field with exponent H” or “a random covariance mixture” does not identify a probability law. Here is a particular construction to conjecture and then test. Its cutoff removal, universality and agreement with the lattice are all unproved and untested here.

Fix 0 < q < 2 and 2 < α < 2 + q/2, put H = (α−2)/q, and choose any fixed η > 0. For ε > 0, define the continuous Gaussian reference

\[
U_\varepsilon=\eta\varepsilon^{H-1/2}B_D,
\]

extended by zero outside D. For a continuous zero-boundary path u, define the finite-cutoff action

\[
\mathcal E_\varepsilon(u)=
\iint_{\substack{(x,y)\in\mathbb R^2\\|x-y|>\varepsilon}}
\frac{|u(x)-u(y)|^q}{|x-y|^\alpha}\,dx\,dy.
\]

The integral includes the whole zero exterior and uses ordered pairs. For every ε > 0 it is finite almost surely under the Gaussian reference. Thus

\[
\nu_\varepsilon^{(\eta)}(du)=
\frac{e^{-\mathcal E_\varepsilon(u)}}{
\mathbb E e^{-\mathcal E_\varepsilon(U_\varepsilon)}}
\operatorname{Law}(U_\varepsilon)(du)
\]

is an actual probability measure; there is no appeal to infinite-dimensional Lebesgue measure.

**Constructive conjecture.** The measures νε⁽η⁾ converge as ε ↓ 0 to a nondegenerate law Q(q,α), independently of η, and the lattice model under the normalization above converges to this same law. In particular its characteristic functional would be

\[
\boxed{\quad
\chi_{q,\alpha}(f)=
\lim_{\varepsilon\downarrow0}
\frac{\mathbb E\exp\{i\langle U_\varepsilon,f\rangle-
\mathcal E_\varepsilon(U_\varepsilon)\}}
{\mathbb E\exp\{-\mathcal E_\varepsilon(U_\varepsilon)\}}.
\quad}
\]

Taking f = Σtⱼfⱼ specifies each proposed finite-dimensional joint law. This prescription has no fitted covariance distribution or marginal-shape parameter. Its existence and the equality with the lattice limit are substantive parts of the conjecture, not definitions that are already known to hold.

The growing reference diffusivity η²ε²ᴴ⁻¹ represents microscopic variance viewed under a subdiffusive spatial rescaling. Its Gaussian local stiffness has coefficient proportional to ε¹⁻²ᴴ, which vanishes at macroscopic scale. Independence of η is a proposed irrelevance of this local regularization; it needs a separate numerical or mathematical test. At q = 2 the quadratic prescription reduces to the Gaussian operator above, providing a consistency check on the convention.

On a dilated domain LD, the construction predicts Qᴸᴰ(Lt) equal in law to LᴴQᴰ(t). This is a statement about a family of domains with matching zero exteriors. It does not claim stationary increments inside the fixed interval, where the boundary matters.

The cutoff cannot simply be discarded inside the action. In particular the unregularized |u(x)−u(y)|/|x−y|²·²⁵ integral can diverge even on nonconstant smooth paths. Writing exp(−E(u)) Du without a prescription would not identify a law.

For 0 < q ≤ 2, the finite-cutoff interaction factors admit positive Gaussian mixtures. Combined with the Gaussian reference, this motivates a random-covariance interpretation of Q. It does **not** imply that one independent scalar amplitude times a fixed Gaussian field describes the limit. The explicit cutoff prescription, rather than that broad description, is the proposed full candidate.

## Exact quadratic anchors and boundary conventions

For q = 2 the model is Gaussian already at finite n. Under the table's normalizations:

\[
\Phi=\begin{cases}
G_\alpha,&1<\alpha<3,\\
\tfrac12 B_D,&\alpha=3,\\
[4\zeta(\alpha-2)]^{-1/2}B_D,&\alpha>3.
\end{cases}
\]

These constants follow from the ordered-pair energy. The Fourier symbol of the lattice L is 2Σr≥1(1−cos kr)/rα. At α = 3 its leading small-k term is k²log(1/|k|); at α > 3 it is ζ(α−2)k². The finite Gaussian precision is 4βL.

On the whole line, the pinned Gaussian field for 2 < α < 3 has the fractional Brownian exponent H = (α−2)/2. With our full zero exterior, the correct limiting object is the restricted Dirichlet fractional Gaussian field. Merely conditioning two endpoint values of an unconditioned fBm does not specify that same exterior condition.

As an additional amplitude check, in the nearest-neighbor limit α → ∞ the increment density is proportional to exp(−2|z|q) at β = 1. Its variance, and hence the squared Brownian amplitude, is

\[
\sigma(q,\infty)^2=2^{-2/q}\frac{\Gamma(3/q)}{\Gamma(1/q)}.
\]

This gives σ(1,∞)² = 1/2 and σ(2,∞)² = 1/4.

## Why these exponents and logarithms are plausible

A macroscopic interaction under φ(nt) ≈ nᴴΦ(t) scales as n²⁻ᵅ⁺ᑫᴴ. Requiring a finite nonzero coefficient gives H = (α−2)/q. This balances the large-scale interaction; it is not a proof that microscopic terms are irrelevant.

Under Brownian scaling H = 1/2 the same coefficient is n²⁻ᵅ⁺ᑫ/². It decreases for α > 2 + q/2, suggesting a Gaussian diffusive limit, and is marginal at equality. A self-consistent quadratic-response heuristic predicts a running stiffness of order (log n)²/ᑫ at that equality, hence height scale √n/(log n)¹/ᑫ. The exact q = 2 logarithm agrees with this expression.

For α < 2, the more speculative picture is a localized microscopic field with a Gaussian long-wavelength response whose fractional exponent is (α−2)/2, independent of q. At α = 2, a self-consistent logarithmic response suggests point variance (log n)²/ᑫ and smooth-average variance (log n)²/ᑫ⁻¹. This is the origin of the separate logarithmic row. The new sweep tests this prediction but does not resolve its asymptotic validity, especially at q = 0.5. These critical claims should be read as hypotheses rather than measured laws.

## The original q = 1, α = 2.25 study

At q = 1, α = 2.25 the conjectured scale is aₙ = n¹/⁴, so the smooth pairing is β n⁻⁵/⁴Σfφ. The largest saved runs give:

| n | Recordings | Var(n⁻⁵/⁴Σfφ) | Excess kurtosis | Approximate 95% block interval |
|---|---:|---:|---:|---|
| 512 | 60,000 | 0.02459 | 0.260 | [0.179, 0.346] |
| 1024 | 60,000 | 0.02468 | 0.302 | [0.164, 0.453] |
| 2048 | 24,000 | 0.02407 | 0.442 | [0.261, 0.625] |

The variance fit gives H ≈ 0.242. At n = 1024, the even-minus-odd excess-kurtosis interval is [0.052, 0.377], and a mixed fourth-cumulant identity also disagrees with the simple model A times G, with A independent of G. At n = 2048 that refinement is inconclusive because its intervals are wider. There are about 514 effective even-bump samples at n = 2048, despite 24,000 recorded configurations.

This supports the exponent and persistent non-Gaussianity as working guesses. It does not select the Brownian cutoff candidate among all non-Gaussian fields. In particular, generalized-normal or variance-gamma fits to one observable cannot establish the joint limiting law.

The new sweep tests fourth cumulants below, at and above the proposed crossover for three nonlinear q values. The remaining discriminating experiments are larger critical boxes and a direct comparison with the cutoff construction at different η. A drift to zero kurtosis at q = 1, α = 2.25, or dependence of the proposed cutoff limit on η, would contradict the corresponding parts of the conjecture.

See [gaussianity.html](gaussianity.html) for the interactive phase diagram and original saved data, [scaling-limit-guess.md](scaling-limit-guess.md) for the original sampling details, and [sweep-report.md](sweep-report.md) for the broader experiment. All 456,000 original recordings are preserved, including the earlier small boxes; 264,000 of those are from the compiled continuation. The new parameter sweep is archived separately.
