"""Prespecified parameter sweep; resume completed chains without overwriting them."""
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
import argparse,json,subprocess,time
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'experiments'/'parameter-sweep'
OUT.mkdir(parents=True,exist_ok=True)
parser=argparse.ArgumentParser()
parser.add_argument('--sizes',default='32,64,128,256,512')
parser.add_argument('--workers',type=int,default=8)
parser.add_argument('--samples',type=int,default=8000)
parser.add_argument('--burn',type=int,default=12000)
parser.add_argument('--only',default='')
args=parser.parse_args()
points=[]
for q in [.5,1,1.5,2]:
    for name,alpha in [('localized',1.75),('lower-critical',2),('rough-mid',2+q/4),('rough-high',2+.4*q),('upper-critical',2+q/2),('near-diffusive',2+q/2+.15),('diffusive',3.5)]:
        key=f'q{q:g}-a{alpha:g}'
        points.append({'key':key,'q':q,'alpha':alpha,'regime':name})
plan={'model':'real heights, complete ordered-pair interaction and zero exterior','beta':1,'points':points,'sizes':[int(n) for n in args.sizes.split(',')],'replicas':3,'samplesPerChain':args.samples,'burn':args.burn,'thin':5,'baseSeed':83009171,'sampler':'sweep-sos.cpp','hypothesesFile':'precise-conjectures.md','adaptation':'Only during warmup; frozen before retention','diagnostics':'even/odd kurtosis, mixed fourth cumulant, block bootstrap, split Rhat, ESS, independent Gaussian covariance checks, energy Gamma(m/q,1) check'}
planfile=OUT/('plan-'+args.sizes.replace(',','-')+'.json')
if not planfile.exists():planfile.write_text(json.dumps(plan,indent=2))
if not (OUT/'original-conjectures.md').exists():(OUT/'original-conjectures.md').write_bytes((ROOT/'precise-conjectures.md').read_bytes())
jobs=[(p,n,r) for n in sorted(plan['sizes']) for p in points if not args.only or p['key'] in args.only.split(',') for r in range(3)]
start=time.time()
def run(job):
    p,n,r=job
    folder=OUT/p['key'];folder.mkdir(exist_ok=True)
    stem=folder/f'n{n}-r{r}'
    meta=stem.with_suffix('.meta.json')
    if meta.exists():
        previous=json.loads(meta.read_text())
        if previous['samples']!=args.samples or previous['burn']!=args.burn:raise RuntimeError('Existing run has a different budget: '+str(stem))
        return {'cached':True,'key':p['key'],'N':n,'replica':r}
    seed=plan['baseSeed']+int(p['q']*100)*10000019+int(round(p['alpha']*1000))*1009+n*9176+r*104729
    cmd=[str(ROOT/'.verification/sweep-sos'),str(n),str(p['q']),str(p['alpha']),str(args.samples),str(args.burn),'5',str(seed),str(r),str(stem)]
    with stem.with_suffix('.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
    result=json.loads(meta.read_text())
    return {'key':p['key'],'N':n,'replica':r,'seconds':round(result['seconds'],1),'qMeanEnergy':round(p['q']*result['meanBetaEnergyPerDimension'],5),'acceptance':result['acceptance'][:2]}
with ThreadPoolExecutor(max_workers=args.workers) as pool:
    futures=[pool.submit(run,job) for job in jobs]
    for done,f in enumerate(as_completed(futures),1):
        result=f.result();result.update(done=done,total=len(jobs),wallSeconds=round(time.time()-start,1))
        print(json.dumps(result),flush=True)
print(json.dumps({'complete':True,'jobs':len(jobs),'seconds':time.time()-start}),flush=True)
