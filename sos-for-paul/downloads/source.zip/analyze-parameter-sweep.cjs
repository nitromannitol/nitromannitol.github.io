'use strict';
// Analyze one completed parameter/size cell at a time; keep baseline data intact.
const fs=require('node:fs'),path=require('node:path');
const R=require('./real-model.js'),{randomGenerator}=require('./model.js');
const ROOT='experiments/parameter-sweep',KEYS=['f','g','left','right','narrow'];
const average=a=>a.reduce((s,x)=>s+x,0)/a.length;
const quantile=(a,p)=>{const i=(a.length-1)*p,j=Math.floor(i);return a[j]+(a[Math.min(j+1,a.length-1)]-a[j])*(i-j);};
const interval=(a,p=.95)=>{a=[...a].sort((x,y)=>x-y);return [quantile(a,(1-p)/2),quantile(a,(1+p)/2)];};
function cov(x,y){const a=average(x),b=average(y);return average(x.map((v,i)=>(v-a)*(y[i]-b)));}
function diagnose(chains){return {rhat:R.splitRhat(chains),rhatSquared:R.splitRhat(chains,true),ess:chains.reduce((s,x)=>s+R.effectiveSamples(x),0),essSquared:chains.reduce((s,x)=>s+R.effectiveSamples(x.map(v=>v*v)),0),essFourth:chains.reduce((s,x)=>s+R.effectiveSamples(x.map(v=>v**4)),0)};}
function readRun(stem){
  const meta=JSON.parse(fs.readFileSync(stem+'.meta.json'));
  const lines=fs.readFileSync(stem+'.csv','utf8').trim().split('\n'),header=lines.shift().split(','),data=Object.fromEntries(header.map(k=>[k,[]]));
  for(const line of lines){const a=line.split(',').map(Number);if(a.length!==header.length||a.some(x=>!Number.isFinite(x)))throw Error('Bad CSV '+stem);header.forEach((k,i)=>data[k].push(a[i]));}
  if(lines.length!==meta.samples)throw Error('Wrong record count '+stem);
  return {meta,data};
}
function evaluate(s,scales){
  const n=s[0],m=[],v=[],k=[];
  for(let j=0;j<5;j++){const off=1+4*j,a=s[off]/n,b=s[off+1]/n,c=s[off+2]/n,d=s[off+3]/n;m.push(a);v.push(b-a*a);k.push((d-4*a*c+6*a*a*b-3*a**4)/v[j]**2-3);}
  const c=s[21]/n-m[0]*m[1],rho=c/Math.sqrt(v[0]*v[1]);
  const mixed=s[24]/n-2*m[0]*s[23]/n-2*m[1]*s[22]/n+4*m[0]*m[1]*s[21]/n+m[0]**2*s[6]/n+m[1]**2*s[2]/n-3*m[0]**2*m[1]**2;
  const wick=(mixed-v[0]*v[1]-2*c*c)/(v[0]*v[1]);
  return {variance:v[0]*scales[0]**2,gVariance:v[1]*scales[1]**2,narrowVariance:v[4]*scales[4]**2,
    fExcess:k[0],gExcess:k[1],narrowExcess:k[4],excessDifference:k[0]-k[1],wick,
    commonScaleResidual:k[1]-3*wick/(1+2*rho*rho),fgCorrelation:rho,
    leftRightCorrelation:(s[25]/n-m[2]*m[3])/Math.sqrt(v[2]*v[3]),
    gfVarianceRatio:v[1]*scales[1]**2/(v[0]*scales[0]**2),narrowfVarianceRatio:v[4]*scales[4]**2/(v[0]*scales[0]**2)};
}
function bootstrap(runs,stats,blockLength,repetitions,seed){
  const scales=KEYS.map(k=>Math.sqrt(stats[k].variance)),means=KEYS.map(k=>stats[k].mean);
  const groups=runs.map(run=>{
    if(run.meta.samples%blockLength)throw Error('Block length must divide retained chain');
    const blocks=[];
    for(let start=0;start<run.meta.samples;start+=blockLength){const s=Array(26).fill(0);s[0]=blockLength;
      for(let i=start;i<start+blockLength;i++){
        const a=KEYS.map((k,j)=>(run.data[k][i]-means[j])/scales[j]);
        for(let j=0;j<5;j++){const z=a[j],off=1+4*j;s[off]+=z;s[off+1]+=z*z;s[off+2]+=z**3;s[off+3]+=z**4;}
        const [x,y,l,r]=a;s[21]+=x*y;s[22]+=x*x*y;s[23]+=x*y*y;s[24]+=x*x*y*y;s[25]+=l*r;
      }blocks.push(s);
    }return blocks;
  });
  const rng=randomGenerator(seed),draws=[];
  for(let b=0;b<repetitions;b++){const sums=Array(26).fill(0);for(const g of groups)for(let i=0;i<g.length;i++){const s=g[Math.floor(rng()*g.length)];for(let k=0;k<s.length;k++)sums[k]+=s[k];}draws.push(evaluate(sums,scales));}
  const intervals={},intervals99={};for(const k of Object.keys(draws[0])){intervals[k]=interval(draws.map(d=>d[k]));intervals99[k]=interval(draws.map(d=>d[k]),.99);}
  const total=Array(26).fill(0);for(const g of groups)for(const s of g)for(let j=0;j<s.length;j++)total[j]+=s[j];
  return {blockLength,repetitions,intervals,intervals99,estimates:evaluate(total,scales),draws};
}
function plots(values,stat){
  const sd=Math.sqrt(stat.variance),z=values.map(x=>(x-stat.mean)/sd),bins=Array(48).fill(0),sorted=[...z].sort((x,y)=>x-y);
  for(const x of z)if(x>=-6&&x<6)bins[Math.floor((x+6)/.25)]++;
  return {histogram:bins.map((n,i)=>({x:-6+(i+.5)*.25,density:n/values.length/.25})),outsideHistogram:z.filter(x=>Math.abs(x)>=6).length,
    qq:Array.from({length:61},(_,i)=>{const p=.001+(.998*i/60);return {p,normal:R.normalQuantile(p),empirical:quantile(sorted,p)};}),
    cf:Array.from({length:17},(_,i)=>({t:i/4,empirical:average(z.map(x=>Math.cos(i*x/4))),gaussian:Math.exp(-.5*(i/4)**2)}))};
}
function brownianCovariance(N){
  const bump=(t,r=.8,c=0)=>Math.abs((t-c)/r)<1?Math.exp(1-1/(1-((t-c)/r)**2)):0;
  const t=Array.from({length:2*N+1},(_,i)=>i/N),func=t.map(s=>{const x=s-1;return [bump(x),3*x/.8*bump(x),bump(x,.25,-.4),bump(x,.25,.4),bump(x,.35)];});
  // Independent Brownian increments of variance 1/N, followed by bridge projection.
  const weightedTime=KEYS.map((_,k)=>func.reduce((sum,v,i)=>sum+v[k]*t[i]/N,0));
  const tail=KEYS.map(()=>0),C=KEYS.map(()=>KEYS.map(()=>0));
  for(let i=2*N;i>=1;i--){for(let k=0;k<5;k++)tail[k]+=func[i][k]/N;const a=tail.map((v,k)=>v-weightedTime[k]/2);for(let j=0;j<5;j++)for(let k=0;k<5;k++)C[j][k]+=a[j]*a[k]/N;}
  return C;
}
function shape(C){return {gfVarianceRatio:C[1][1]/C[0][0],narrowfVarianceRatio:C[4][4]/C[0][0],leftRightCorrelation:C[2][3]/Math.sqrt(C[2][2]*C[3][3])};}
function analyzeCell(point,N,runs){
  const all=k=>runs.flatMap(r=>r.data[k]),stats={};for(const k of [...KEYS,'centre','energy','inc','inc2'])stats[k]=R.moments(all(k));
  const diagnostics={};for(const k of ['f','g','narrow','energy','inc'])diagnostics[k]=diagnose(runs.map(r=>r.data[k]));
  const seed=N+Math.round(point.q*100)*7711+Math.round(point.alpha*1000)*713;
  const boot=bootstrap(runs,stats,500,1000,seed),alt=[250,1000].map(b=>bootstrap(runs,stats,b,400,seed+b));
  const scaling=R.candidateScaling(point.q,point.alpha),factor=R.candidateNormalization(N,point.q,point.alpha).factor;
  const fields=KEYS.map(all),C=fields.map(x=>fields.map(y=>cov(x,y)));
  const inc=all('inc'),adj=all('inc2').map((x,i)=>x-inc[i]);
  const exactFile=path.join(ROOT,'references',`n${N}-a${point.alpha}.json`),ref=point.q===2&&fs.existsSync(exactFile)?JSON.parse(fs.readFileSync(exactFile)):null;
  const effAlpha=scaling.H<=0?point.alpha:scaling.H<.5?2+2*scaling.H:null;
  const analogyFile=effAlpha?path.join(ROOT,'references',`n${N}-a${Number(effAlpha.toFixed(8))}.json`):null;
  const analogy=analogyFile&&fs.existsSync(analogyFile)?JSON.parse(fs.readFileSync(analogyFile)):null;
  const pooledEnergy=stats.energy;
  const cell={...point,N,sampler:runs[0].meta.sampler||'metropolis',count:runs.reduce((s,r)=>s+r.meta.samples,0),stats,diagnostics,covariance:C,
    normalization:{...scaling,factor,variance:stats.f.variance*factor**2,varianceInterval:boot.intervals.variance.map(x=>x*factor**2)},
    joint:boot.estimates,bootstrap:{blockLength:500,repetitions:1000,intervals:boot.intervals,intervals99:boot.intervals99,
      sensitivity:alt.map(b=>({blockLength:b.blockLength,repetitions:b.repetitions,intervals:b.intervals}))},
    increments:{relativeLag:runs[0].meta.lag/N,adjacentCorrelation:cov(inc,adj)/Math.sqrt(stats.inc.variance*R.moments(adj).variance),varianceRatio:stats.inc2.variance/stats.inc.variance,brownianBridgeAdjacentCorrelation:-1/15},
    energy:{qMeanPerDimension:point.q*pooledEnergy.mean/(2*N+1),qVariancePerDimension:point.q*pooledEnergy.variance/(2*N+1),expected:1,maxEnergyDrift:Math.max(...runs.map(r=>Math.abs(r.meta.energyDrift)))},
    gaussianControl:ref?{exactVariance:ref.covariance[0][0],varianceRatio:stats.f.variance/ref.covariance[0][0],varianceRatioInterval:boot.intervals.variance.map(x=>x/ref.covariance[0][0]),shape:shape(ref.covariance)}:null,
    gaussianAnalogy:analogy?{alpha:effAlpha,...shape(analogy.covariance)}:null,brownianShape:shape(brownianCovariance(N)),
    plots:{f:plots(all('f'),stats.f),g:plots(all('g'),stats.g)},
    chains:runs.map(r=>({replica:r.meta.replica,seed:String(r.meta.seed),burn:r.meta.burn,thin:r.meta.thin,samples:r.meta.samples,seconds:r.meta.seconds,acceptance:r.meta.acceptance,
      qMeanEnergy:r.meta.q*r.meta.meanBetaEnergyPerDimension,qVarianceEnergy:r.meta.q*r.meta.varianceBetaEnergyPerDimension,
      early:R.moments(r.data.f.slice(0,r.meta.samples/2)),late:R.moments(r.data.f.slice(r.meta.samples/2)),
      moments:Object.fromEntries(['f','g','narrow','energy'].map(k=>[k,R.moments(r.data[k])])),
      trace:r.data.f.filter((_,i)=>i%40===0).map(x=>x*factor),
      profile:r.meta.finalHeights.map((v,i)=>({x:(i-N)/N,y:v/(N**scaling.H*Math.log(N)**scaling.logPower)})).filter((_,i)=>i%Math.max(1,Math.floor(N/128))===0)}))};
  const maxRhat=Math.max(...Object.values(diagnostics).flatMap(d=>[d.rhat,d.rhatSquared]));
  cell.quality={maxRhat,minSmoothESS:Math.min(...['f','g','narrow'].map(k=>diagnostics[k].ess)),minFourthESS:Math.min(...['f','g','narrow'].map(k=>diagnostics[k].essFourth)),
    adequate:maxRhat<1.01&&Math.min(...['f','g','narrow'].map(k=>diagnostics[k].ess))>=1000};
  return {cell,varianceDraws:boot.draws.map(x=>({f:x.variance,g:x.gVariance,narrow:x.narrowVariance}))};
}
function slope(xs,ys){const mx=average(xs),my=average(ys);return xs.reduce((s,x,i)=>s+(x-mx)*(ys[i]-my),0)/xs.reduce((s,x)=>s+(x-mx)**2,0);}
function scalingFit(rows,draws,key,logPower=0,fixedH=null){
  const xs=rows.map(c=>fixedH===null?Math.log(c.N):Math.log(Math.log(c.N))),project=(vars)=>vars.map((v,i)=>.5*Math.log(v)-Math.log(rows[i].N)-(fixedH===null?logPower*Math.log(Math.log(rows[i].N)):fixedH*Math.log(rows[i].N)));
  const estimate=slope(xs,project(rows.map(c=>c.stats[key].variance))),distribution=[];
  for(let b=0;b<1000;b++)distribution.push(slope(xs,project(rows.map(c=>draws.get(c.key+'/'+c.N)[b][key]))));
  return {estimate,interval:interval(distribution),sizes:rows.map(c=>c.N)};
}
const plan=JSON.parse(fs.readFileSync(path.join(ROOT,'plan-32-64-128-256-512.json'))),results=[],baselineResults=[],draws=new Map(),cache=path.join(ROOT,'analysis-cache');fs.mkdirSync(cache,{recursive:true});
const baseOnly=process.argv.includes('--base-only');
let generatedRecordings=0,generatedChains=0;
for(const point of plan.points){
  const folder=path.join(ROOT,point.key);if(!fs.existsSync(folder))continue;
  const extended=path.join(ROOT,'extended',point.key),folders=baseOnly?[folder]:[folder,...(fs.existsSync(extended)?[extended]:[])];
  for(const dir of folders)for(const file of fs.readdirSync(dir).filter(f=>/^n\d+-r\d+\.meta\.json$/.test(f))){generatedRecordings+=JSON.parse(fs.readFileSync(path.join(dir,file))).samples;generatedChains++;}
  const sizes=[...new Set(folders.flatMap(dir=>fs.readdirSync(dir)).filter(f=>/^n\d+-r\d+\.meta\.json$/.test(f)).map(f=>Number(f.match(/^n(\d+)/)[1])))].sort((a,b)=>a-b);
  for(const N of sizes){let selected;
    for(const dir of folders){const stems=[0,1,2].map(r=>path.join(dir,`n${N}-r${r}`));if(!stems.every(s=>fs.existsSync(s+'.meta.json')))continue;
      const clustered=dir===extended,cached=path.join(cache,`${point.key}-n${N}${clustered?'-cluster':''}.json`);let a;
      if(fs.existsSync(cached))a=JSON.parse(fs.readFileSync(cached));else {a=analyzeCell(point,N,stems.map(readRun));fs.writeFileSync(cached,JSON.stringify(a));console.log(JSON.stringify({key:point.key,N,sampler:a.cell.sampler,kurtosis:a.cell.stats.f.excess,interval:a.cell.bootstrap.intervals.fExcess,rhat:a.cell.diagnostics.f.rhat,ess:a.cell.diagnostics.f.ess}));}
      a.cell.sampler=clustered?'cluster':'metropolis';if(!clustered)baselineResults.push(a.cell);selected=a;
    }
    if(selected){
      const original=baselineResults.find(c=>c.key===point.key&&c.N===N);
      if(selected.cell.sampler==='cluster'&&original)selected.cell.originalMetropolis={count:original.count,stats:{f:original.stats.f,g:original.stats.g},diagnostics:{f:original.diagnostics.f,g:original.diagnostics.g},normalization:original.normalization,kurtosisInterval:original.bootstrap.intervals.fExcess,quality:original.quality};
      results.push(selected.cell);draws.set(point.key+'/'+N,selected.varianceDraws);
    }
  }
}
const pairs=plan.points.map(p=>{
  const cells=results.filter(c=>c.key===p.key);if(cells.length<2)return {...p,cells:cells.length};
  const largest=cells[cells.length-1],last=cells.slice(-3),scaling=R.candidateScaling(p.q,p.alpha);
  const fits=Object.fromEntries(['f','g','narrow'].map(k=>[k,{raw:scalingFit(last,draws,k),corrected:scalingFit(last,draws,k,scaling.logPower),allSizes:scalingFit(cells,draws,k,scaling.logPower),logPower:scaling.logPower?scalingFit(last,draws,k,0,scaling.H):null}]));
  return {...p,cells:cells.length,largestN:largest.N,predicted:scaling,fits,
    normalizedVarianceRatio:largest.normalization.variance/last[0].normalization.variance,
    gaussianExactFit:p.q===2&&last.every(c=>c.gaussianControl)?slope(last.map(c=>Math.log(c.N)),last.map(c=>.5*Math.log(c.gaussianControl.exactVariance)-Math.log(c.N)-scaling.logPower*Math.log(Math.log(c.N)))):null,
    adequateAtLargest:largest.quality.adequate};
});
const output={generatedAt:new Date().toISOString(),plan,configurations:results.reduce((s,c)=>s+c.count,0),totalGeneratedRecordings:generatedRecordings,totalGeneratedChains:generatedChains,completedCells:results.length,completedChains:results.reduce((s,c)=>s+c.chains.length,0),
  statisticalNotes:['All intervals are approximate pointwise block-bootstrap intervals, not simultaneous confidence bands.','The three chains are resampled separately; warmup adaptation is frozen before retained samples.','Nonoverlapping blocks of 500 retained recordings; sensitivity at 250 and 1000 recordings. A recording is made every 5 Metropolis sweeps or every 3 sweeps augmented with two reflection clusters.','Split Rhat is the conventional unranked statistic. ESS uses an initial monotone positive autocorrelation sequence truncated at lag 1000.','Power fits use the three largest available sizes. Confidence intervals quantify Monte Carlo uncertainty, not finite-size bias.','Positive finite-size kurtosis does not by itself imply a non-Gaussian scaling limit.','Where complete cluster runs exist they are displayed in place of the original slower sampler; all original runs and their analyses are retained in the downloads.'],pairs,results};
fs.writeFileSync(path.join(ROOT,baseOnly?'baseline-summary.json':'summary.json'),JSON.stringify(output));
if(!baseOnly){fs.writeFileSync('parameter-sweep-data.js','window.PARAMETER_SWEEP = '+JSON.stringify(output)+';\n');fs.writeFileSync(path.join(ROOT,'baseline-cells.json'),JSON.stringify(baselineResults));
fs.writeFileSync('parameter-sweep-status.js','window.PARAMETER_SWEEP_STATUS = '+JSON.stringify(pairs.map(p=>({q:p.q,alpha:p.alpha,N:p.largestN})))+';\n');}
const header=['q','alpha','regime','N','count','variance_f','normalized_variance_f','excess_f','excess_f_low95','excess_f_high95','excess_g','wick','rhat_f','rhat_f_squared','ess_f','ess_f_fourth','q_mean_energy','q_variance_energy'];
const rows=results.map(c=>[c.q,c.alpha,c.regime,c.N,c.count,c.stats.f.variance,c.normalization.variance,c.stats.f.excess,...c.bootstrap.intervals.fExcess,c.stats.g.excess,c.joint.wick,c.diagnostics.f.rhat,c.diagnostics.f.rhatSquared,c.diagnostics.f.ess,c.diagnostics.f.essFourth,c.energy.qMeanPerDimension,c.energy.qVariancePerDimension]);
fs.writeFileSync(path.join(ROOT,baseOnly?'baseline-summary.csv':'summary.csv'),[header.join(','),...rows.map(a=>a.join(','))].join('\n')+'\n');
console.log(JSON.stringify({complete:true,cells:results.length,configurations:output.configurations,pairs:pairs.map(p=>({q:p.q,alpha:p.alpha,H:p.fits?.f.corrected,predicted:p.predicted,quality:p.adequateAtLargest}))}));
