const assert = require('node:assert/strict');
const R = require('./real-model.js');
const close = (a,b,tol) => assert.ok(Math.abs(a-b)<tol, `${a} != ${b}`);
for(const q of [1,2]) {
  const c = new R.RealChain({N:3,q,alpha:2.25,beta:1});
  c.heights.set([-.37,.21,.58,-.84,1.27,.018,-.69]);
  for(let i=0;i<c.n;i++) {
    const initial=c.hamiltonian(),delta=c.localDelta(i,.173);
    c.heights[i]+=.173;close(c.hamiltonian()-initial,delta,1e-10);c.heights[i]-=.173;
  }
  const initial=c.hamiltonian(),delta=c.blockDelta(1,4,-.432);
  for(let i=1;i<=4;i++)c.heights[i]-=.432;
  close(c.hamiltonian()-initial,delta,1e-10);
}
const laplace=new R.RealChain({N:0,q:1,alpha:2,beta:1,seed:718});
const laplaceValues=[];
for(let i=0;i<405000;i++){laplace.sweep();if(i>=5000&&i%2===0)laplaceValues.push(laplace.heights[0]);}
const lm=R.moments(laplaceValues),expected=2/(2*Math.PI**2/3)**2;
close(lm.variance,expected,expected*.04);close(lm.excess,3,.4);
const gaussian=new R.GaussianChain({N:8,alpha:2.25,beta:1,seed:918});
const f=R.testFunctions(8).f, exact=R.gaussianFunctionalVariance(gaussian,f,gaussian.factor),values=[];
for(let i=0;i<20000;i++){gaussian.sweep();values.push(gaussian.heights.reduce((s,x,j)=>s+x*f[j],0));}
const gm=R.moments(values);close(gm.variance,exact,.04*exact);close(gm.excess,0,.15);
close(gaussian.energy,gaussian.hamiltonian(),1e-9);
close(R.normalQuantile(.975),1.9599639845,1e-7);
assert.equal(R.bump(.8),0);assert.equal(R.bump(-.8),0);assert.equal(R.bump(0),1);
assert.ok(laplace.heights.some(x=>!Number.isInteger(x)));
console.log(JSON.stringify({passed:true,continuousLaplace:{variance:lm.variance,exactVariance:expected,excess:lm.excess,exactExcess:3},exactGaussian:{variance:gm.variance,exactVariance:exact,excess:gm.excess},checks:'Fractional-height energy deltas, Laplace marginal, Gaussian weighted covariance, no rounding, Q-Q quantiles'},null,2));
