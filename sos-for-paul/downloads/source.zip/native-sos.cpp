// Dense, real q=1 Metropolis sampler. Every interaction is retained.
// Compile: clang++ -O3 -march=native -ffast-math -std=c++17 native-sos.cpp -o .verification/native-sos
#include <algorithm>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
using Vec=std::vector<double>;
double tail(double s,int start){
  const int end=start+32;double sum=0;
  for(int i=start;i<end;i++)sum+=std::pow(i,-s);
  sum+=std::pow(end,1-s)/(s-1)+.5*std::pow(end,-s);
  const double coeff[]={1./12,-1./720,1./30240,-1./1209600,1./47900160};double rising=s;
  for(int k=1;k<=5;k++){if(k>1)rising*=(s+2*k-3)*(s+2*k-2);sum+=coeff[k-1]*rising*std::pow(end,-s-2*k+1);}
  return sum;
}
double bump(double x,double r=.8,double c=0){double t=(x-c)/r;return std::abs(t)<1?std::exp(1-1/(1-t*t)):0;}
struct Chain{
  int N,m;double alpha,beta,H=0,localScale,smoothMultiplier;long sweeps=0;
  Vec h,w,b,proposal,scales;std::vector<Vec> directions,functions;std::mt19937_64 rng;
  long attempts[3]={0,0,0},accepts[3]={0,0,0};
  Chain(int n,double a,double beta_,unsigned long long seed,double sm=24):N(n),m(2*n+1),alpha(a),beta(beta_),smoothMultiplier(sm),h(m),w(m),b(m),proposal(m),rng(seed){
    for(int d=1;d<m;d++)w[d]=std::pow(d,-alpha);
    for(int i=0;i<m;i++)b[i]=tail(alpha,i+1)+tail(alpha,m-i);
    localScale=3/(4*beta*tail(alpha,1));
    functions.assign(5,Vec(m));
    for(int i=0;i<m;i++){double t=N?double(i-N)/N:0;functions[0][i]=bump(t);functions[1][i]=3*t/.8*bump(t);functions[2][i]=bump(t,.25,-.4);functions[3][i]=bump(t,.25,.4);functions[4][i]=bump(t,.35);}
    directions.push_back(Vec(m,1));
    directions.insert(directions.end(),functions.begin(),functions.end());
    for(const auto& d:directions){double e=energy(d);scales.push_back(e>0?smoothMultiplier/(beta*e):0);}
  }
  double U(){return std::generate_canonical<double,53>(rng);}
  double step(){return (2*U()-1)*localScale*(U()<.9?1:8);}
  bool accept(double d){return d<=0||U()<std::exp(-beta*d);}
  double energy(const Vec& x)const{
    double e=0;for(int i=0;i<m;i++){e+=b[i]*std::abs(x[i]);double row=0;
      for(int j=i+1;j<m;j++)row+=w[j-i]*std::abs(x[i]-x[j]);e+=row;}
    return 2*e;
  }
  double localDelta(int i,double d)const{
    const double old=h[i],nw=old+d;double e=b[i]*(std::abs(nw)-std::abs(old));
    double left=0,right=0;
    for(int j=0;j<i;j++)left+=w[i-j]*(std::abs(nw-h[j])-std::abs(old-h[j]));
    for(int j=i+1;j<m;j++)right+=w[j-i]*(std::abs(nw-h[j])-std::abs(old-h[j]));
    return 2*(e+left+right);
  }
  double blockDelta(int l,int r,double d)const{
    double e=0;for(int i=l;i<=r;i++){
      const double old=h[i],nw=old+d;e+=b[i]*(std::abs(nw)-std::abs(old));double left=0,right=0;
      for(int j=0;j<l;j++)left+=w[i-j]*(std::abs(nw-h[j])-std::abs(old-h[j]));
      for(int j=r+1;j<m;j++)right+=w[j-i]*(std::abs(nw-h[j])-std::abs(old-h[j]));e+=left+right;
    }return 2*e;
  }
  void sweep(){
    for(int k=0;k<m;k++){int i=int(U()*m);double d=step(),change=localDelta(i,d);attempts[0]++;if(accept(change)){h[i]+=d;H+=change;accepts[0]++;}}
    int levels=int(std::ceil(std::log2(m)))+1;
    for(int k=0;k<4;k++){int length=std::min(m,1<<int(U()*levels)),l=int(U()*(m-length+1)),r=l+length-1;double d=step(),change=blockDelta(l,r,d);attempts[1]++;if(accept(change)){for(int i=l;i<=r;i++)h[i]+=d;H+=change;accepts[1]++;}}
    // Fixed, symmetric collective proposals improve exploration of coarse modes.
    int k=int(U()*directions.size());double d=(2*U()-1)*scales[k];
    for(int i=0;i<m;i++)proposal[i]=h[i]+d*directions[k][i];
    double next=energy(proposal);attempts[2]++;if(accept(next-H)){h.swap(proposal);H=next;accepts[2]++;}
    sweeps++;if(sweeps%1024==0)H=energy(h);
  }
};
void test(){
  if(std::abs(tail(2,1)-std::acos(-1)*std::acos(-1)/6)>1e-12)throw std::runtime_error("tail");
  Chain c(3,2.25,1,791);c.h={-.37,.21,.58,-.84,1.27,.018,-.69};
  for(int i=0;i<c.m;i++)for(double d:{-.173,.412}){double e=c.energy(c.h),change=c.localDelta(i,d);c.h[i]+=d;if(std::abs(c.energy(c.h)-e-change)>1e-10)throw std::runtime_error("local delta");c.h[i]-=d;}
  for(int l=0;l<c.m;l++)for(int r=l;r<c.m;r++){double e=c.energy(c.h),change=c.blockDelta(l,r,.231);for(int i=l;i<=r;i++)c.h[i]+=.231;if(std::abs(c.energy(c.h)-e-change)>1e-10)throw std::runtime_error("block delta");for(int i=l;i<=r;i++)c.h[i]-=.231;}
  Chain one(0,2,1,4718);double m2=0,m4=0;int samples=300000;
  for(int i=0;i<samples+5000;i++){one.sweep();if(i>=5000){m2+=one.h[0]*one.h[0]/samples;m4+=std::pow(one.h[0],4)/samples;}}
  double exact=2/std::pow(4*tail(2,1),2);if(std::abs(m2/exact-1)>.04||std::abs(m4/(m2*m2)-6)>.6)throw std::runtime_error("Laplace marginal");
  std::cout<<"{\"passed\":true,\"laplaceVariance\":"<<m2<<",\"exact\":"<<exact<<",\"excess\":"<<m4/(m2*m2)-3<<"}\n";
}
int main(int argc,char**argv){
  try{
    if(argc==2&&std::string(argv[1])=="--test"){test();return 0;}
    if(argc<8){std::cerr<<"Usage: native-sos N samples burn thin seed replica output-stem [smooth-multiplier]\n";return 1;}
    int N=std::stoi(argv[1]),samples=std::stoi(argv[2]),burn=std::stoi(argv[3]),thin=std::stoi(argv[4]),replica=std::stoi(argv[6]);
    auto seed=std::stoull(argv[5]);std::string stem=argv[7];double sm=argc>8?std::stod(argv[8]):24;
    if(N<0||N>4096||samples<1||burn<0||thin<1)throw std::runtime_error("invalid parameters");
    std::filesystem::create_directories(std::filesystem::path(stem).parent_path());
    Chain c(N,2.25,1,seed,sm);
    double amplitude=(replica-1)*std::pow(std::max(1,N),.25);
    for(int i=0;i<c.m;i++)c.h[i]=amplitude*c.functions[0][i];c.H=c.energy(c.h);
    std::vector<int> lags,positions;for(int r=1;r<=N/2;r*=2)lags.push_back(r);
    for(int j=0;j<9;j++)positions.push_back(N+int(std::round(N*(-.8+.2*j))));
    std::ofstream out(stem+".csv");out<<std::setprecision(17)<<"sweep,energy,f,g,left,right,narrow,centre";
    for(int i=0;i<9;i++)out<<",p"<<i;for(int lag:lags)out<<",inc"<<lag;out<<"\n";
    auto start=std::chrono::steady_clock::now();double lastProgress=0;Vec incSum(lags.size());double eSum=0,eSquare=0;
    for(int i=0;i<burn+samples*thin;i++){
      c.sweep();
      if(c.sweeps>burn&&(c.sweeps-burn)%thin==0){
        eSum+=c.H;eSquare+=c.H*c.H;out<<c.sweeps<<','<<c.H;
        for(const auto& f:c.functions){double sum=0;for(int j=0;j<c.m;j++)sum+=f[j]*c.h[j];out<<','<<sum;}
        out<<','<<c.h[N];for(int p:positions)out<<','<<c.h[p];
        for(size_t j=0;j<lags.size();j++){double d=c.h[N+lags[j]]-c.h[N];incSum[j]+=d*d;out<<','<<d;}out<<'\n';
      }
      if(c.sweeps%1000==0){double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();if(elapsed-lastProgress>=20){std::cout<<"{\"N\":"<<N<<",\"replica\":"<<replica<<",\"sweeps\":"<<c.sweeps<<",\"total\":"<<burn+samples*thin<<",\"seconds\":"<<elapsed<<"}\n"<<std::flush;lastProgress=elapsed;}}
    }
    double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
    std::ofstream meta(stem+".meta.json");meta<<std::setprecision(17);
    auto array=[&meta](const auto& values){meta<<'[';for(size_t i=0;i<values.size();i++){if(i)meta<<',';meta<<values[i];}meta<<']';};
    meta<<"{\"N\":"<<N<<",\"q\":1,\"alpha\":2.25,\"beta\":1,\"seed\":"<<seed<<",\"replica\":"<<replica<<",\"samples\":"<<samples<<",\"burn\":"<<burn<<",\"thin\":"<<thin<<",\"smoothMultiplier\":"<<sm<<",\"seconds\":"<<elapsed<<",\"meanBetaEnergyPerDimension\":"<<eSum/samples/c.m<<",\"varianceBetaEnergyPerDimension\":"<<(eSquare/samples-std::pow(eSum/samples,2))/c.m<<",\"energyDrift\":"<<c.H-c.energy(c.h)<<",\"lags\":";array(lags);meta<<",\"incrementSums\":";array(incSum);meta<<",\"positions\":";array(positions);meta<<",\"finalHeights\":";array(c.h);meta<<",\"acceptance\":[";for(int k=0;k<3;k++){if(k)meta<<',';meta<<double(c.accepts[k])/c.attempts[k];}meta<<"]}\n";
    std::cout<<"{\"complete\":true,\"N\":"<<N<<",\"replica\":"<<replica<<",\"seconds\":"<<elapsed<<",\"meanEnergyPerDimension\":"<<eSum/samples/c.m<<"}\n";
  }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}
  return 0;
}
