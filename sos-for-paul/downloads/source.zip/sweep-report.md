# Parameter sweep: evidence and revised assessment

The broader experiment supports the non-Gaussian rough-field guess at additional parameters and supports Brownian behavior well above the proposed crossover. It does **not** justify treating the entire extrapolated phase diagram as established. The critical logarithms and the location of the nonlinear crossover remain the weakest parts of the guess.

The [interactive sweep](parameter-sweep.html) shows every pair, every box size, three observable kurtoses, distributions, Q–Q plots, traces, covariance ratios and mixing diagnostics. The [data page](data.html#parameter-sweep) contains every original and additional recording, together with seeds, plans and code.

## What was actually run

The initial grid contains **28 parameter pairs**, each at **n = 32, 64, 128, 256, 512**, with three independently seeded chains: **420 chains and 3,360,000 recordings**. Each chain had 12,000 warmup sweeps, followed by 8,000 recordings spaced five sweeps apart. The seven alpha choices at each q sample below 2, at 2, two rough-regime points, the proposed upper boundary, a point just above it, and 3.5.

| q | Values of α |
|---:|---|
| 0.5 | 1.75, 2, 2.125, 2.2, 2.25, 2.4, 3.5 |
| 1 | 1.75, 2, 2.25, 2.4, 2.5, 2.65, 3.5 |
| 1.5 | 1.75, 2, 2.375, 2.6, 2.75, 2.9, 3.5 |
| 2 | 1.75, 2, 2.5, 2.8, 3, 3.15, 3.5 |

Some of the larger-box Metropolis chains mixed poorly. We retained them and added **108 cluster chains with 864,000 recordings**, covering the critical and higher-alpha regimes for q = 0.5, 1, 1.5, the rough-high points, and a q = 2, α = 3.5 benchmark. These had 12,000 warmup sweeps and 8,000 recordings spaced three augmented sweeps apart.

We then added **three independent 40,000-recording chains at q = 1.5, α = 2.375, n = 512**, after the initial fourth-moment interval was inconclusive. This precision extension is exploratory and is recorded in a separate plan.

The sweep therefore generated **4,344,000 recordings in 531 chains**. Its primary plots use 3,456,000 recordings, choosing the complete cluster run where available. The original slower runs are preserved separately rather than pooled into those plots. Including the earlier q = 1, α = 2.25 study, the project preserves **4,800,000 recordings**. Separate sampler-validation runs are not included in those totals.

## Rough regime: a second and third q value

At the rough-mid points α = 2 + q/4, the original prediction is H = 1/4. Every row below uses n = 128, 256, 512 for its variance fit, and reports kurtosis at n = 512. The quadratic row has an exactly Gaussian law and is an independent benchmark for interpretation.

| q | α | Fitted H, approximate 95% interval | κ(f), approximate 95% interval | ESS(f) |
|---:|---:|---|---|---:|
| 0.5 | 2.125 | 0.245 [0.222, 0.266] | 0.531 [0.352, 0.717] | 1,268 |
| 1 | 2.25 | 0.241 [0.224, 0.261] | 0.340 [0.221, 0.459] | 1,327 |
| 1.5 | 2.375 | 0.222 [0.212, 0.233] | 0.113 [0.075, 0.155] | 41,736 |
| 2 | 2.5 | 0.228 [0.213, 0.242] | -0.047 [-0.115, 0.032] | 1,426 |

For q = 0.5, α = 2.125, the fitted exponent is close to 1/4 and the even-bump excess kurtosis is clearly positive. Its normalized mixed fourth residual is 0.244, with interval [0.164, 0.326]; joint Gaussianity would make this zero. This provides evidence beyond the original q = 1 point. The longer q = 1.5 run also resolves positive finite-size excess kurtosis.

These results favor a non-Gaussian field in the rough regime. They do not identify its full characteristic functional. In particular, the continuum Brownian-cutoff prescription in the [conjectures](conjectures.html) has not been simulated, and the present lattice sweep cannot select it among different non-Gaussian laws.

The powers still need scrutiny. At q = 1.5, the rough-mid effective exponent is 0.222, below the proposed 0.25. At the rough-high points α = 2 + 0.4q, the fitted exponents are **q = 0.5: 0.291, q = 1: 0.332, q = 1.5: 0.344**, all below the proposed 0.4. Thus the clean asymptotic powers have not emerged uniformly on these boxes. The exact Gaussian comparison below shows why a narrow Monte Carlo interval does not remove this finite-size limitation.

## Well above the proposed crossover

At α = 3.5 the original prediction is a Brownian bridge with deterministic amplitude. The cluster runs greatly improve the precision of this comparison.

| q | α | Fitted H, approximate 95% interval | κ(f), approximate 95% interval | ESS(f) |
|---:|---:|---|---|---:|
| 0.5 | 3.5 | 0.496 [0.481, 0.510] | 0.125 [-0.007, 0.275] | 7,217 |
| 1 | 3.5 | 0.496 [0.481, 0.510] | -0.007 [-0.074, 0.058] | 7,825 |
| 1.5 | 3.5 | 0.492 [0.479, 0.504] | 0.064 [-0.022, 0.154] | 8,042 |
| 2 | 3.5 | 0.479 [0.465, 0.492] | -0.045 [-0.132, 0.044] | 8,781 |

For q = 0.5, α = 3.5, the measured ratio Var(g)/Var(f) is 0.234 [0.224, 0.246]; the Brownian-bridge value is 0.232. The left/right bump correlation is 0.493 [0.474, 0.509], compared with 0.496 for the bridge. These ratios remove an unknown deterministic amplitude and test more than a single marginal histogram.

The improved sampling matters. In the original q = 0.5, α = 3.5, n = 256 run, there were only about 58 effective even-bump samples across 24,000 recordings. A separate cluster pilot produced about 2,300 from 6,000 recordings. Conclusions about Gaussianity based on the original slow trace would have been unreliable.

## Close to the crossover and at the critical points

Being above the proposed αc = 2 + q/2 does not make our accessible boxes visibly Gaussian. At q = 0.5, α = 2.4, the n = 512 excess kurtosis is 0.323 [0.203, 0.436], and the mixed fourth residual is 0.151 [0.103, 0.194]. This is an important qualification of the original diagram: a Gaussian limiting law here would require further decay beyond the simulated sizes.

The critical normalization was aₙ = nᴴ(log n)ℓ, with H = 0, ℓ = 1/q − 1/2 at α = 2, and H = 1/2, ℓ = −1/q at α = 2 + q/2. Holding H fixed, the three-largest-size fits give:

| q | α | Proposed log power ℓ | Fitted ℓ with H fixed | κ(f) at n = 512 |
|---:|---:|---:|---|---|
| 0.5 | 2 | 1.500 | 0.671 [0.577, 0.765] | 0.600 [0.388, 0.817] |
| 1 | 2 | 0.500 | 0.273 [0.218, 0.325] | 0.232 [0.144, 0.328] |
| 1.5 | 2 | 0.167 | 0.125 [0.069, 0.180] | 0.119 [0.047, 0.193] |
| 0.5 | 2.25 | -2.000 | -0.950 [-1.050, -0.848] | 0.673 [0.523, 0.832] |
| 1 | 2.5 | -1.000 | -0.695 [-0.781, -0.606] | 0.209 [0.120, 0.305] |
| 1.5 | 2.75 | -0.667 | -0.542 [-0.609, -0.472] | 0.069 [0.001, 0.133] |
| 2 | 3 | -0.500 | -0.378 [-0.518, -0.250]; exact covariance fit -0.471 | -0.022 [-0.112, 0.070] |

The quadratic critical Metropolis run is flagged by the mixing screen; its separately computed exact covariance fit is included in the table. Its finite-dimensional law is Gaussian regardless of sampler performance.

The nonlinear critical normalizations do not yet give a convincingly constant scaled variance across this window, especially at q = 0.5. The table distinguishes the stated log powers from measured effective log powers. An additive constant inside a logarithm can produce substantial drift over five sizes, so these discrepancies do not alone distinguish an incorrect asymptotic exponent from a long crossover. The exact nonlinear log powers should remain **unresolved hypotheses**.

This is also why an ordinary power fit should not be used to locate the crossover. In the exact q = 2, α = 2.8 model, the finite covariance gives an effective H of **0.356** on n = 128–512, even though the limiting H is 0.4. The same finite-size issue can affect the nonlinear fits.

## Below α = 2

At α = 1.75, the q = 0.5 and q = 1 even-bump kurtoses decrease over the full size range, while the measured powers show q-dependent drift relative to H = −1/8. This is consistent with a Gaussian long-wavelength limit, but detectable non-Gaussian finite-size effects remain. The shrinking scale applies to the smooth spatial average, not to a single height.

The revised interpretation is: retain the rough-field and far-diffusive pictures as working guesses; treat the exact nonlinear critical powers, the crossover position and the proposed full cutoff law as separate questions requiring stronger evidence.

## Full numerical comparison

The fitted H below subtracts the originally proposed logarithm when present. Its interval quantifies Monte Carlo uncertainty, not the difference between a finite-size effective exponent and an asymptotic exponent. The interactive page also gives the uncorrected distributions and all intermediate sizes.

| q | α | Proposed H | Fitted H, approximate 95% interval | κ(f), approximate 95% interval | Screen at n = 512 |
|---:|---:|---:|---|---|---|
| 0.5 | 1.75 | -0.125 | -0.089 [-0.100, -0.077] | 0.109 [0.043, 0.177] | Pass |
| 0.5 | 2 | 0.000 | -0.150 [-0.168, -0.133] | 0.600 [0.388, 0.817] | Pass |
| 0.5 | 2.125 | 0.250 | 0.245 [0.222, 0.266] | 0.531 [0.352, 0.717] | Pass |
| 0.5 | 2.2 | 0.400 | 0.291 [0.266, 0.313] | 0.591 [0.455, 0.724] | Pass |
| 0.5 | 2.25 | 0.500 | 0.690 [0.671, 0.708] | 0.673 [0.523, 0.832] | Pass |
| 0.5 | 2.4 | 0.500 | 0.410 [0.392, 0.427] | 0.323 [0.203, 0.436] | Pass |
| 0.5 | 3.5 | 0.500 | 0.496 [0.481, 0.510] | 0.125 [-0.007, 0.275] | Pass |
| 1 | 1.75 | -0.125 | -0.094 [-0.105, -0.085] | 0.125 [0.047, 0.224] | Pass |
| 1 | 2 | 0.000 | -0.041 [-0.050, -0.031] | 0.232 [0.144, 0.328] | Pass |
| 1 | 2.25 | 0.250 | 0.241 [0.224, 0.261] | 0.340 [0.221, 0.459] | Pass |
| 1 | 2.4 | 0.400 | 0.332 [0.316, 0.347] | 0.223 [0.108, 0.361] | Pass |
| 1 | 2.5 | 0.500 | 0.555 [0.539, 0.571] | 0.209 [0.120, 0.305] | Pass |
| 1 | 2.65 | 0.500 | 0.431 [0.416, 0.446] | 0.143 [0.076, 0.215] | Pass |
| 1 | 3.5 | 0.500 | 0.496 [0.481, 0.510] | -0.007 [-0.074, 0.058] | Pass |
| 1.5 | 1.75 | -0.125 | -0.120 [-0.129, -0.109] | 0.074 [0.011, 0.145] | Pass |
| 1.5 | 2 | 0.000 | -0.007 [-0.017, 0.003] | 0.119 [0.047, 0.193] | Pass |
| 1.5 | 2.375 | 0.250 | 0.222 [0.212, 0.233] | 0.113 [0.075, 0.155] | Pass |
| 1.5 | 2.6 | 0.400 | 0.344 [0.328, 0.360] | 0.149 [0.060, 0.240] | Pass |
| 1.5 | 2.75 | 0.500 | 0.522 [0.510, 0.535] | 0.069 [0.001, 0.133] | Pass |
| 1.5 | 2.9 | 0.500 | 0.434 [0.421, 0.447] | 0.038 [-0.034, 0.115] | Pass |
| 1.5 | 3.5 | 0.500 | 0.492 [0.479, 0.504] | 0.064 [-0.022, 0.154] | Pass |
| 2 | 1.75 | -0.125 | -0.130 [-0.140, -0.121] | 0.049 [-0.008, 0.105] | Pass |
| 2 | 2 | 0.000 | 0.002 [-0.009, 0.013] | 0.056 [-0.025, 0.146] | Pass |
| 2 | 2.5 | 0.250 | 0.228 [0.213, 0.242] | -0.047 [-0.115, 0.032] | Pass |
| 2 | 2.8 | 0.400 | 0.357 [0.334, 0.381] | -0.040 [-0.139, 0.057] | Inspect diagnostics |
| 2 | 3 | 0.500 | 0.522 [0.496, 0.546] | -0.022 [-0.112, 0.070] | Inspect diagnostics |
| 2 | 3.15 | 0.500 | 0.423 [0.397, 0.452] | -0.018 [-0.095, 0.051] | Inspect diagnostics |
| 2 | 3.5 | 0.500 | 0.479 [0.465, 0.492] | -0.045 [-0.132, 0.044] | Pass |

## Sampler and statistical checks

All heights are real. Every lattice pair is included, together with the entire infinite zero exterior. We use the ordered-pair Hamiltonian from the numerical specification and β = 1. There is no range cutoff, no integer rounding, and no energy resampling used to enforce a check.

A Metropolis sweep contains 2n+1 random-site proposals, four interval proposals and two smooth collective proposals. Proposal scales adapt only during warmup and are then frozen. The cluster sampler adds two embedded-Ising reflection clusters to each sweep. A seed and a reflection plane are selected; a pair with positive reflection cost Δ is joined with probability 1 − exp(−βΔ). The fixed exterior is a ghost vertex, and a cluster attached to that vertex is left unchanged. The plane displacement has a symmetric density about the seed height, which is unchanged by the reverse reflection. Together with the bond probabilities, this gives detailed balance for the same real-valued Gibbs law, including q &lt; 1.

The native sampler passed independent local and block energy-difference checks and single-site generalized-normal checks at all four q values. The cluster sampler was checked against exact finite Gaussian covariances at n = 16, α = 1.75 and 3.5, using 40,000 recordings per check. The three checked projection variances agreed within about 1.3%.

Homogeneity gives the independent exact identity βH ∼ Gamma((2n+1)/q, 1). Across displayed cells, q E[H]/(2n+1) lies in [0.997, 1.002], and q Var(H)/(2n+1) lies in [0.962, 1.037]; both should equal 1. Exact Gaussian covariances were computed separately by Cholesky solution of the full finite precision matrix 4L.

Across 35 displayed quadratic cells, the mean measured/exact even-bump variance ratio is 0.999. The approximate 95% variance intervals contain the exact answer in 33 of 35 cells, and the kurtosis intervals contain zero in 34 of 35 cells. We report this coverage rather than forcing every control to pass: the intervals are pointwise, and occasional misses are expected when many cells are inspected.

We report conventional split R̂ for both the observable and its square; effective sample estimates for the observable, its square and its fourth power; independent-chain traces; and stratified block-bootstrap intervals. The primary bootstrap uses 1,000 resamples of blocks of 500 retained recordings. Sensitivity intervals use blocks of 250 and 1,000 recordings. The square and fourth-power diagnostics matter because ordinary mean ESS can look adequate while tail estimates remain noisy. The plots flag cells with R̂ ≥ 1.01 or fewer than 1,000 effective samples in one of the three displayed smooth projections. Every flagged cell remains visible.

All inferences are exploratory. The original parameter grid and conjectures were saved before running it; the subsequent extensions and their reasons are preserved separately. The intervals are not simultaneous across all 28 pairs. Persistent fourth cumulants favor a non-Gaussian limit, while finite-size positive kurtosis alone does not distinguish persistence from a slow decay to zero.

## Reproduce the sweep

Download the source archive and the per-pair ZIPs from the [data page](data.html#parameter-sweep), preserving their paths. Raw CSV values are stored at full printed precision. On this machine the samplers were compiled with clang++; the Gaussian reference uses macOS Accelerate.

```bash
mkdir -p .verification
clang++ -O3 -march=native -ffast-math -std=c++17 sweep-sos.cpp -o .verification/sweep-sos
clang++ -O3 -march=native -ffast-math -std=c++17 cluster-sos.cpp -o .verification/cluster-sos
.verification/sweep-sos --test
python3 run-parameter-sweep.py
python3 run-sweep-extensions.py
python3 run-sweep-extensions.py --rough-high --workers 3
python3 run-sweep-extensions.py --precision --workers 3
node analyze-parameter-sweep.cjs
node audit-parameter-sweep.cjs
```

Extract the plans-and-checks archive as well to supply the exact covariance references. The original q = 1, α = 2.25 study through n = 2048 is preserved in the [earlier detailed report](results.html). Its data have not been replaced by the parameter sweep.
