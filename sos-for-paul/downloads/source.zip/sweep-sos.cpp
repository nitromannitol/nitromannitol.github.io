// Real q-SOS parameter sweep. Full pairs and infinite exterior; no cutoff.
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
using Vec=std::vector<double>;
double zetaTail(double s,int start){
  const int end=start+32;double value=0;for(int r=start;r<end;r++)value+=std::pow(r,-s);
  value+=std::pow(end,1-s)/(s-1)+.5*std::pow(end,-s);
  const double c[]={1./12,-1./720,1./30240,-1./1209600,1./47900160};double rising=s;
  for(int k=1;k<=5;k++){if(k>1)rising*=(s+2*k-3)*(s+2*k-2);value+=c[k-1]*rising*std::pow(end,-s-2*k+1);}return value;
}
double bump(double x,double r=.8,double center=0){const double t=(x-center)/r;return std::abs(t)<1?std::exp(1-1/(1-t*t)):0;}
template<int Q> struct Chain{
  static constexpr double q=Q*.5;
  int N,m;double alpha,beta,H=0,localScale,blockScale;long sweeps=0;
  Vec h,w,b,proposal,scales;std::vector<Vec> functions,directions;std::mt19937_64 rng;
  std::array<long,8> attempted{},accepted{},windowAttempts{},windowAccepts{};int adaptations=0;
  Chain(int n,double a,double bet,unsigned long long seed):N(n),m(2*n+1),alpha(a),beta(bet),h(m),w(m),b(m),proposal(m),rng(seed){
    for(int r=1;r<m;r++)w[r]=std::pow(r,-alpha);
    for(int i=0;i<m;i++)b[i]=zetaTail(alpha,i+1)+zetaTail(alpha,m-i);
    localScale=3*std::pow(4*beta*zetaTail(alpha,1),-1/q);blockScale=localScale;
    functions.assign(5,Vec(m));for(int i=0;i<m;i++){const double t=N?double(i-N)/N:0;functions[0][i]=bump(t);functions[1][i]=3*t/.8*bump(t);functions[2][i]=bump(t,.25,-.4);functions[3][i]=bump(t,.25,.4);functions[4][i]=bump(t,.35);}
    directions.push_back(Vec(m,1));directions.insert(directions.end(),functions.begin(),functions.end());
    for(const auto& d:directions){double e=energy(d);scales.push_back(e?4*std::pow(beta*e,-1/q):0);}
  }
  static double V(double x){x=std::abs(x);if constexpr(Q==1)return std::sqrt(x);if constexpr(Q==2)return x;if constexpr(Q==3)return x*std::sqrt(x);return x*x;}
  double U(){return std::generate_canonical<double,53>(rng);}
  double delta(double scale){return (2*U()-1)*scale*(U()<.9?1:8);}
  bool accept(double change,int kind){attempted[kind]++;windowAttempts[kind]++;bool yes=change<=0||U()<std::exp(-beta*change);if(yes){accepted[kind]++;windowAccepts[kind]++;}return yes;}
  double energy(const Vec& x)const{double e=0;for(int i=0;i<m;i++){e+=b[i]*V(x[i]);double row=0;for(int j=i+1;j<m;j++)row+=w[j-i]*V(x[i]-x[j]);e+=row;}return 2*e;}
  double localDelta(int i,double d)const{const double old=h[i],nw=old+d;double e=b[i]*(V(nw)-V(old)),left=0,right=0;for(int j=0;j<i;j++)left+=w[i-j]*(V(nw-h[j])-V(old-h[j]));for(int j=i+1;j<m;j++)right+=w[j-i]*(V(nw-h[j])-V(old-h[j]));return 2*(e+left+right);}
  double blockDelta(int l,int r,double d)const{double e=0;for(int i=l;i<=r;i++){double old=h[i],nw=old+d,left=0,right=0;e+=b[i]*(V(nw)-V(old));for(int j=0;j<l;j++)left+=w[i-j]*(V(nw-h[j])-V(old-h[j]));for(int j=r+1;j<m;j++)right+=w[j-i]*(V(nw-h[j])-V(old-h[j]));e+=left+right;}return 2*e;}
  void adapt(){
    adaptations++;double gain=.9/std::sqrt(1+adaptations/10.);
    auto change=[&](double& scale,int k){if(scale>0&&windowAttempts[k])scale*=std::exp(gain*(double(windowAccepts[k])/windowAttempts[k]-(k<2?.44:.35)));};
    change(localScale,0);change(blockScale,1);for(int k=0;k<6;k++)change(scales[k],k+2);
    windowAttempts.fill(0);windowAccepts.fill(0);
  }
  void sweep(){
    for(int k=0;k<m;k++){int i=int(U()*m);double d=delta(localScale),change=localDelta(i,d);if(accept(change,0)){h[i]+=d;H+=change;}}
    const int levels=int(std::ceil(std::log2(m)))+1;
    for(int k=0;k<4;k++){int len=std::min(m,1<<int(U()*levels)),l=int(U()*(m-len+1));double d=delta(blockScale),change=blockDelta(l,l+len-1,d);if(accept(change,1)){for(int i=l;i<l+len;i++)h[i]+=d;H+=change;}}
    for(int step=0;step<2;step++){int k=int(U()*6);if(!scales[k])continue;double d=delta(scales[k]);for(int i=0;i<m;i++)proposal[i]=h[i]+d*directions[k][i];double next=energy(proposal);if(accept(next-H,k+2)){h.swap(proposal);H=next;}}
    sweeps++;if(sweeps%1024==0)H=energy(h);
  }
};
template<int Q> void numericalTest(){
  Chain<Q> c(3,2.25,1,971);c.h={-.37,.21,.58,-.84,1.27,.018,-.69};
  for(int i=0;i<c.m;i++)for(double d:{-.193,.471}){const double e=c.energy(c.h),de=c.localDelta(i,d);c.h[i]+=d;if(std::abs(c.energy(c.h)-e-de)>1e-10)throw std::runtime_error("local energy delta");c.h[i]-=d;}
  for(int l=0;l<c.m;l++)for(int r=l;r<c.m;r++){double e=c.energy(c.h),de=c.blockDelta(l,r,.237);for(int i=l;i<=r;i++)c.h[i]+=.237;if(std::abs(c.energy(c.h)-e-de)>1e-10)throw std::runtime_error("block energy delta");for(int i=l;i<=r;i++)c.h[i]-=.237;}
  Chain<Q> one(0,2,1,1709+Q);const int count=Q==1?1600000:400000;double m2=0,m4=0,energy=0;
  for(int j=0;j<count+12000;j++){one.sweep();if(j<12000&&j%500==499)one.adapt();if(j>=12000){m2+=one.h[0]*one.h[0]/count;m4+=std::pow(one.h[0],4)/count;energy+=one.H/count;}}
  const double q=Q*.5,coef=4*zetaTail(2,1),exact=std::tgamma(3/q)/std::tgamma(1/q)*std::pow(coef,-2/q),excess=std::tgamma(5/q)*std::tgamma(1/q)/std::pow(std::tgamma(3/q),2)-3;
  if(std::abs(m2/exact-1)>.075||std::abs(energy*q-1)>.04)throw std::runtime_error("single-site generalized-normal check");
  std::cout<<"{\"q\":"<<q<<",\"varianceRatio\":"<<m2/exact<<",\"excess\":"<<m4/(m2*m2)-3<<",\"exactExcess\":"<<excess<<",\"qMeanEnergy\":"<<q*energy<<"}\n";
}
template<int Q,typename Sampler=Chain<Q>> int run(int N,double alpha,int samples,int burn,int thin,unsigned long long seed,int replica,const std::string& stem){
  const double q=Q*.5;Sampler c(N,alpha,1,seed);
  const double guessH=alpha<=2?0:std::min((alpha-2)/q,.5),amplitude=(replica-1)*std::pow(std::max(1,N),guessH);
  for(int i=0;i<c.m;i++)c.h[i]=amplitude*c.functions[0][i];c.H=c.energy(c.h);
  std::filesystem::create_directories(std::filesystem::path(stem).parent_path());
  std::ofstream out(stem+".csv");out<<std::setprecision(17)<<"sweep,energy,f,g,left,right,narrow,centre,pminus,pplus,inc,inc2\n";
  const int lag=std::max(1,N/8);double e=0,e2=0;auto start=std::chrono::steady_clock::now();
  for(int sweep=1;sweep<=burn+samples*thin;sweep++){
    c.sweep();if(sweep<=burn&&sweep%500==0)c.adapt();
    if(sweep==burn){c.attempted.fill(0);c.accepted.fill(0);}
    if(sweep>burn&&(sweep-burn)%thin==0){out<<sweep<<','<<c.H;e+=c.H;e2+=c.H*c.H;for(const auto& f:c.functions){double sum=0;for(int i=0;i<c.m;i++)sum+=f[i]*c.h[i];out<<','<<sum;}
      out<<','<<c.h[N]<<','<<c.h[N-N/4]<<','<<c.h[N+N/4]<<','<<c.h[N+lag]-c.h[N]<<','<<c.h[N+2*lag]-c.h[N]<<'\n';}
  }
  std::ofstream meta(stem+".meta.json");meta<<std::setprecision(17);
  auto arr=[&](const auto& x){meta<<'[';for(size_t i=0;i<x.size();i++){if(i)meta<<',';meta<<x[i];}meta<<']';};
  meta<<"{\"N\":"<<N<<",\"q\":"<<q<<",\"alpha\":"<<alpha<<",\"beta\":1,\"samples\":"<<samples<<",\"burn\":"<<burn<<",\"thin\":"<<thin<<",\"seed\":"<<seed<<",\"replica\":"<<replica<<",\"seconds\":"<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<",\"meanBetaEnergyPerDimension\":"<<e/samples/c.m<<",\"varianceBetaEnergyPerDimension\":"<<(e2/samples-std::pow(e/samples,2))/c.m<<",\"exactMeanEnergyPerDimension\":"<<1/q<<",\"exactVarianceEnergyPerDimension\":"<<1/q<<",\"energyDrift\":"<<c.H-c.energy(c.h)<<",\"lag\":"<<lag<<",\"adaptation\":\"warmup only; frozen for every retained sample\",\"localScale\":"<<c.localScale<<",\"blockScale\":"<<c.blockScale<<",\"smoothScales\":";arr(c.scales);meta<<",\"acceptance\":[";
  for(int k=0;k<8;k++){if(k)meta<<',';meta<<(c.attempted[k]?double(c.accepted[k])/c.attempted[k]:0);}meta<<"],\"finalHeights\":";arr(c.h);meta<<"}\n";return 0;
}
int main(int argc,char** argv){
  try{
    if(argc==2&&std::string(argv[1])=="--test"){numericalTest<1>();numericalTest<2>();numericalTest<3>();numericalTest<4>();return 0;}
    if(argc!=10)throw std::runtime_error("Usage: sweep-sos N q alpha samples burn thin seed replica output-stem");
    int N=std::stoi(argv[1]),Q=int(std::round(2*std::stod(argv[2]))),samples=std::stoi(argv[4]),burn=std::stoi(argv[5]),thin=std::stoi(argv[6]),replica=std::stoi(argv[8]);double alpha=std::stod(argv[3]);auto seed=std::stoull(argv[7]);std::string stem=argv[9];
    if(N<8||N>4096||alpha<=1||samples<32||burn<500||thin<1||std::abs(Q*.5-std::stod(argv[2]))>1e-9)throw std::runtime_error("Invalid parameters");
    switch(Q){case 1:return run<1>(N,alpha,samples,burn,thin,seed,replica,stem);case 2:return run<2>(N,alpha,samples,burn,thin,seed,replica,stem);case 3:return run<3>(N,alpha,samples,burn,thin,seed,replica,stem);case 4:return run<4>(N,alpha,samples,burn,thin,seed,replica,stem);default:throw std::runtime_error("Supported q: 0.5, 1, 1.5, 2");}
  }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
