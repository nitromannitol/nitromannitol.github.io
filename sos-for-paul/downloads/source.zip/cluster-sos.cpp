// Exact embedded-Ising reflection clusters for the same real q-SOS measure.
// The unchanged Metropolis sweep is retained; two cluster moves follow it.
#define main base_sampler_main
#include "sweep-sos.cpp"
#undef main
template<int Q> struct ClusterChain:Chain<Q>{
  using Base=Chain<Q>;
  using Base::N;using Base::m;using Base::h;using Base::w;using Base::b;using Base::H;using Base::beta;
  std::vector<int> queue;std::vector<unsigned char> inside;double clusterScale;
  ClusterChain(int n,double a,double bet,unsigned long long seed):Base(n,a,bet,seed),inside(this->m){
    const double q=Base::q,exponent=a<=2?0:std::min((a-2)/q,.5);
    clusterScale=std::sqrt(std::tgamma(3/q)/std::tgamma(1/q))*std::pow(2*bet,-1/q)*std::pow(std::max(1,n),exponent);
  }
  void cluster(){
    std::fill(inside.begin(),inside.end(),0);queue.clear();
    const int seed=int(this->U()*m),levels=int(std::ceil(std::log2(std::max(2,m))))+1;
    // Conditional plane density is symmetric about the seed height. Reflecting
    // the seed reverses its displacement from the same plane, so this selection
    // has the same forward/reverse density. No scale depends on retained data.
    const double scale=clusterScale*std::pow(2.,-.5*int(this->U()*levels));
    const double plane=h[seed]+(2*this->U()-1)*scale;
    inside[seed]=1;queue.push_back(seed);
    for(size_t head=0;head<queue.size();head++){
      const int i=queue[head];const double reflected=2*plane-h[i];
      const double exteriorDelta=2*b[i]*(Base::V(reflected)-Base::V(h[i]));
      // Every exterior height is the same fixed ghost spin; its edge rates add.
      if(exteriorDelta>0&&this->U()<-std::expm1(-beta*exteriorDelta))return;
      for(int j=0;j<m;j++)if(!inside[j]){
        const double delta=2*w[std::abs(i-j)]*(Base::V(reflected-h[j])-Base::V(h[i]-h[j]));
        if(delta>0&&this->U()<-std::expm1(-beta*delta)){inside[j]=1;queue.push_back(j);}
      }
    }
    for(int i:queue)h[i]=2*plane-h[i];H=this->energy(h);
  }
  void sweep(){Base::sweep();cluster();cluster();}
};
int main(int argc,char**argv){
  try{
    if(argc!=10)throw std::runtime_error("Usage: cluster-sos N q alpha samples burn thin seed replica output-stem");
    int n=std::stoi(argv[1]),Q=int(std::round(2*std::stod(argv[2]))),samples=std::stoi(argv[4]),burn=std::stoi(argv[5]),thin=std::stoi(argv[6]),r=std::stoi(argv[8]);
    double a=std::stod(argv[3]);auto seed=std::stoull(argv[7]);std::string stem=argv[9];
    if(n<8||n>4096||a<=1||samples<32||burn<500||thin<1||std::abs(Q*.5-std::stod(argv[2]))>1e-9)throw std::runtime_error("Invalid parameters");
    switch(Q){case 1:return run<1,ClusterChain<1>>(n,a,samples,burn,thin,seed,r,stem);case 2:return run<2,ClusterChain<2>>(n,a,samples,burn,thin,seed,r,stem);case 3:return run<3,ClusterChain<3>>(n,a,samples,burn,thin,seed,r,stem);case 4:return run<4,ClusterChain<4>>(n,a,samples,burn,thin,seed,r,stem);default:throw std::runtime_error("q must be 0.5, 1, 1.5 or 2");}
  }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
