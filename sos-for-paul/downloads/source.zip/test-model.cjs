'use strict';
const assert = require('node:assert/strict');
const { Chain, Observables, continuousVariance, zetaTail, theory } = require('./model.js');
const close = (actual, expected, tolerance = 1e-10) => assert.ok(Math.abs(actual - expected) <= tolerance, `${actual} != ${expected}`);

close(zetaTail(2, 1), Math.PI ** 2 / 6);
close(zetaTail(4, 1), Math.PI ** 4 / 90);
for (const alpha of [1.1, 2, 2.6, 3, 4.5]) {
  for (const start of [1, 10, 200]) close(zetaTail(alpha, start) - zetaTail(alpha, start + 1), start ** -alpha);
  const c = new Chain({ N: 3, alpha });
  for (let i = 0; i < c.n; i++) {
    let diagonal = c.boundary[i];
    for (let j = 0; j < c.n; j++) if (j !== i) diagonal += c.weights[Math.abs(i - j)];
    close(diagonal, 2 * zetaTail(alpha, 1));
  }
}
for (const q of [0.5, 0.75, 1, 1.5, 2]) {
  const c = new Chain({ N: 3, q, alpha: 2.6 });
  c.heights.set([-3, 2, 0, 4, -1, 2, -2]);
  for (let i = 0; i < c.n; i++) for (const step of [-4, -1, 1, 8]) {
    const initial = c.hamiltonian(), delta = c.localDelta(i, step);
    c.heights[i] += step; close(c.hamiltonian() - initial, delta); c.heights[i] -= step;
  }
  for (let l = 0; l < c.n; l++) for (let r = l; r < c.n; r++) for (const step of [-2, 1, 4]) {
    const initial = c.hamiltonian(), delta = c.blockDelta(l, r, step);
    for (let i = l; i <= r; i++) c.heights[i] += step;
    close(c.hamiltonian() - initial, delta);
    close(c.blockDelta(l, r, -step), -delta);
    for (let i = l; i <= r; i++) c.heights[i] -= step;
  }
}
// Independent exact enumeration: alpha=2 has zeta(2)=pi^2/6.
// The finite height window is enlarged to verify negligible truncation.
function exactThreeSites(q, beta, cutoff) {
  const diagonal = Math.PI ** 2 / 3;
  let Z = 0, moment = 0;
  for (let a = -cutoff; a <= cutoff; a++) for (let b = -cutoff; b <= cutoff; b++) for (let c = -cutoff; c <= cutoff; c++) {
    const V = x => Math.abs(x) ** q;
    const H = 2 * (V(a - b) + V(b - c) + .25 * V(a - c) + (diagonal - 1.25) * (V(a) + V(c)) + (diagonal - 2) * V(b));
    const p = Math.exp(-beta * H);
    Z += p; moment += b * b * p;
  }
  return moment / Z;
}
const report = [];
for (const q of [0.75, 1, 2]) {
  const beta = .45;
  const expected = exactThreeSites(q, beta, 16);
  close(expected, exactThreeSites(q, beta, 24), 1e-6);
  const c = new Chain({ N: 1, alpha: 2, q, beta, seed: 572 + q * 100 });
  const o = new Observables(5000, 2);
  for (let i = 0; i < 205000; i++) { c.sweep(); o.record(c); }
  const s = o.stats();
  close(s.variance, expected, 6 * s.standardError + .003);
  close(c.energy, c.hamiltonian(), 1e-8);
  assert.equal(s.count, 100000);
  assert.equal(o.trajectory().length, 50000);
  assert.equal(o.trajectory()[0].sweep, 105002);
  report.push({ q, exactVariance: expected, sampledVariance: s.variance, standardError: s.standardError, samples: s.count });
}
const one = new Chain({ N: 0, alpha: 2, q: 2, beta: .2 });
one.heights[0] = 1;
close(one.hamiltonian(), 2 * Math.PI ** 2 / 3);
close(continuousVariance({ N: 0, alpha: 2, beta: .2 }), 1 / (8 * .2 * Math.PI ** 2 / 6));
assert.equal(theory({ q: 2, alpha: 2 }).name, 'Temperature-dependent');
assert.ok(theory({ q: 1, alpha: 2.5 }).formula.includes('log N'));
const a = new Chain({ seed: 123 }), b = new Chain({ seed: 123 });
for (let i = 0; i < 50; i++) { a.sweep(); b.sweep(); }
assert.deepEqual(a.heights, b.heights);
console.log(JSON.stringify({ passed: true, checks: 'Infinite exterior; ordered-pair normalization; local and interval energy differences; independent exact enumeration; Gaussian reference; seeded reproducibility; sample retention', enumeration: report }, null, 2));
