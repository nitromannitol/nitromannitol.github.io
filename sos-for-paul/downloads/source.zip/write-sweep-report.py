"""Render numerical findings from the completed sweep, without rounding raw data."""
from pathlib import Path
import json,math
root=Path(__file__).resolve().parent
s=json.loads((root/'experiments/parameter-sweep/summary.json').read_text())
audit=json.loads((root/'experiments/parameter-sweep/audit.json').read_text())
assert s['totalGeneratedChains']==531 and s['completedCells']==140
def fmt(x):return f'{x:.3f}'
def ci(x):return '['+', '.join(fmt(v) for v in x)+']'
def pair(q,regime):return next(p for p in s['pairs'] if p['q']==q and p['regime']==regime)
def cell(p):return next(c for c in s['results'] if c['key']==p['key'] and c['N']==p['largestN'])
def slope(x,y):
 mx=sum(x)/len(x);my=sum(y)/len(y)
 return sum((a-mx)*(b-my) for a,b in zip(x,y))/sum((a-mx)**2 for a in x)
def evidence_table(regime):
 lines=['| q | α | Fitted H, approximate 95% interval | κ(f), approximate 95% interval | ESS(f) |','|---:|---:|---|---|---:|']
 for q in [.5,1,1.5,2]:
  p=pair(q,regime);c=cell(p);fit=p['fits']['f']['corrected']
  lines.append(f'| {q:g} | {p["alpha"]:g} | {fmt(fit["estimate"])} {ci(fit["interval"])} | {fmt(c["stats"]["f"]["excess"])} {ci(c["bootstrap"]["intervals"]["fExcess"])} | {c["diagnostics"]["f"]["ess"]:,.0f} |')
 return '\n'.join(lines)
critical=['| q | α | Proposed log power ℓ | Fitted ℓ with H fixed | κ(f) at n = 512 |','|---:|---:|---:|---|---|']
for regime in ['lower-critical','upper-critical']:
 for q in [.5,1,1.5,2]:
  p=pair(q,regime);f=p['fits']['f']['logPower'];c=cell(p)
  if f:
   fitted=fmt(f['estimate'])+' '+ci(f['interval'])
   if q==2:
    rows=[r for r in s['results'] if r['key']==p['key']][-3:]
    exact=slope([math.log(math.log(r['N'])) for r in rows],[.5*math.log(r['gaussianControl']['exactVariance'])-1.5*math.log(r['N']) for r in rows])
    fitted+='; exact covariance fit '+fmt(exact)
   critical.append(f'| {q:g} | {p["alpha"]:g} | {fmt(p["predicted"]["logPower"])} | {fitted} | {fmt(c["stats"]["f"]["excess"])} {ci(c["bootstrap"]["intervals"]["fExcess"])} |')
grid=['| q | Values of α |','|---:|---|']
for q in [.5,1,1.5,2]:grid.append('| '+f'{q:g}'+' | '+', '.join(f'{p["alpha"]:g}' for p in s['pairs'] if p['q']==q)+' |')
allrows=['| q | α | Proposed H | Fitted H, approximate 95% interval | κ(f), approximate 95% interval | Screen at n = 512 |','|---:|---:|---:|---|---|---|']
for p in s['pairs']:
 c=cell(p);f=p['fits']['f']['corrected'];allrows.append(f'| {p["q"]:g} | {p["alpha"]:g} | {fmt(p["predicted"]["H"])} | {fmt(f["estimate"])} {ci(f["interval"])} | {fmt(c["stats"]["f"]["excess"])} {ci(c["bootstrap"]["intervals"]["fExcess"])} | '+('Pass' if c['quality']['adequate'] else 'Inspect diagnostics')+' |')
rough=cell(pair(.5,'rough-mid'));near=cell(pair(.5,'near-diffusive'));far=cell(pair(.5,'diffusive'))
quad=pair(2,'rough-high')
q15=cell(pair(1.5,'rough-mid'))
q15statement=('The longer q = 1.5 run also resolves positive finite-size excess kurtosis.' if q15['bootstrap']['intervals']['fExcess'][0]>0 else 'The longer q = 1.5 run still does not cleanly resolve a nonzero even-bump fourth cumulant; its interval should be read directly.')
highfits=', '.join('q = '+f'{q:g}'+': '+fmt(pair(q,'rough-high')['fits']['f']['corrected']['estimate']) for q in [.5,1,1.5])
text=rf'''# Parameter sweep: evidence and revised assessment

The broader experiment supports the non-Gaussian rough-field guess at additional parameters and supports Brownian behavior well above the proposed crossover. It does **not** justify treating the entire extrapolated phase diagram as established. The critical logarithms and the location of the nonlinear crossover remain the weakest parts of the guess.

The [interactive sweep](parameter-sweep.html) shows every pair, every box size, three observable kurtoses, distributions, Q–Q plots, traces, covariance ratios and mixing diagnostics. The [data page](data.html#parameter-sweep) contains every original and additional recording, together with seeds, plans and code.

## What was actually run

The initial grid contains **28 parameter pairs**, each at **n = 32, 64, 128, 256, 512**, with three independently seeded chains: **420 chains and 3,360,000 recordings**. Each chain had 12,000 warmup sweeps, followed by 8,000 recordings spaced five sweeps apart. The seven alpha choices at each q sample below 2, at 2, two rough-regime points, the proposed upper boundary, a point just above it, and 3.5.

{chr(10).join(grid)}

Some of the larger-box Metropolis chains mixed poorly. We retained them and added **108 cluster chains with 864,000 recordings**, covering the critical and higher-alpha regimes for q = 0.5, 1, 1.5, the rough-high points, and a q = 2, α = 3.5 benchmark. These had 12,000 warmup sweeps and 8,000 recordings spaced three augmented sweeps apart.

We then added **three independent 40,000-recording chains at q = 1.5, α = 2.375, n = 512**, after the initial fourth-moment interval was inconclusive. This precision extension is exploratory and is recorded in a separate plan.

The sweep therefore generated **{s['totalGeneratedRecordings']:,} recordings in {s['totalGeneratedChains']} chains**. Its primary plots use {s['configurations']:,} recordings, choosing the complete cluster run where available. The original slower runs are preserved separately rather than pooled into those plots. Including the earlier q = 1, α = 2.25 study, the project preserves **4,800,000 recordings**. Separate sampler-validation runs are not included in those totals.

## Rough regime: a second and third q value

At the rough-mid points α = 2 + q/4, the original prediction is H = 1/4. Every row below uses n = 128, 256, 512 for its variance fit, and reports kurtosis at n = 512. The quadratic row has an exactly Gaussian law and is an independent benchmark for interpretation.

{evidence_table('rough-mid')}

For q = 0.5, α = 2.125, the fitted exponent is close to 1/4 and the even-bump excess kurtosis is clearly positive. Its normalized mixed fourth residual is {fmt(rough['joint']['wick'])}, with interval {ci(rough['bootstrap']['intervals']['wick'])}; joint Gaussianity would make this zero. This provides evidence beyond the original q = 1 point. {q15statement}

These results favor a non-Gaussian field in the rough regime. They do not identify its full characteristic functional. In particular, the continuum Brownian-cutoff prescription in the [conjectures](conjectures.html) has not been simulated, and the present lattice sweep cannot select it among different non-Gaussian laws.

The powers still need scrutiny. At q = 1.5, the rough-mid effective exponent is {fmt(pair(1.5,'rough-mid')['fits']['f']['corrected']['estimate'])}, below the proposed 0.25. At the rough-high points α = 2 + 0.4q, the fitted exponents are **{highfits}**, all below the proposed 0.4. Thus the clean asymptotic powers have not emerged uniformly on these boxes. The exact Gaussian comparison below shows why a narrow Monte Carlo interval does not remove this finite-size limitation.

## Well above the proposed crossover

At α = 3.5 the original prediction is a Brownian bridge with deterministic amplitude. The cluster runs greatly improve the precision of this comparison.

{evidence_table('diffusive')}

For q = 0.5, α = 3.5, the measured ratio Var(g)/Var(f) is {fmt(far['joint']['gfVarianceRatio'])} {ci(far['bootstrap']['intervals']['gfVarianceRatio'])}; the Brownian-bridge value is {fmt(far['brownianShape']['gfVarianceRatio'])}. The left/right bump correlation is {fmt(far['joint']['leftRightCorrelation'])} {ci(far['bootstrap']['intervals']['leftRightCorrelation'])}, compared with {fmt(far['brownianShape']['leftRightCorrelation'])} for the bridge. These ratios remove an unknown deterministic amplitude and test more than a single marginal histogram.

The improved sampling matters. In the original q = 0.5, α = 3.5, n = 256 run, there were only about 58 effective even-bump samples across 24,000 recordings. A separate cluster pilot produced about 2,300 from 6,000 recordings. Conclusions about Gaussianity based on the original slow trace would have been unreliable.

## Close to the crossover and at the critical points

Being above the proposed αc = 2 + q/2 does not make our accessible boxes visibly Gaussian. At q = 0.5, α = 2.4, the n = 512 excess kurtosis is {fmt(near['stats']['f']['excess'])} {ci(near['bootstrap']['intervals']['fExcess'])}, and the mixed fourth residual is {fmt(near['joint']['wick'])} {ci(near['bootstrap']['intervals']['wick'])}. This is an important qualification of the original diagram: a Gaussian limiting law here would require further decay beyond the simulated sizes.

The critical normalization was aₙ = nᴴ(log n)ℓ, with H = 0, ℓ = 1/q − 1/2 at α = 2, and H = 1/2, ℓ = −1/q at α = 2 + q/2. Holding H fixed, the three-largest-size fits give:

{chr(10).join(critical)}

The quadratic critical Metropolis run is flagged by the mixing screen; its separately computed exact covariance fit is included in the table. Its finite-dimensional law is Gaussian regardless of sampler performance.

The nonlinear critical normalizations do not yet give a convincingly constant scaled variance across this window, especially at q = 0.5. The table distinguishes the stated log powers from measured effective log powers. An additive constant inside a logarithm can produce substantial drift over five sizes, so these discrepancies do not alone distinguish an incorrect asymptotic exponent from a long crossover. The exact nonlinear log powers should remain **unresolved hypotheses**.

This is also why an ordinary power fit should not be used to locate the crossover. In the exact q = 2, α = 2.8 model, the finite covariance gives an effective H of **{fmt(quad['gaussianExactFit'])}** on n = 128–512, even though the limiting H is 0.4. The same finite-size issue can affect the nonlinear fits.

## Below α = 2

At α = 1.75, the q = 0.5 and q = 1 even-bump kurtoses decrease over the full size range, while the measured powers show q-dependent drift relative to H = −1/8. This is consistent with a Gaussian long-wavelength limit, but detectable non-Gaussian finite-size effects remain. The shrinking scale applies to the smooth spatial average, not to a single height.

The revised interpretation is: retain the rough-field and far-diffusive pictures as working guesses; treat the exact nonlinear critical powers, the crossover position and the proposed full cutoff law as separate questions requiring stronger evidence.

## Full numerical comparison

The fitted H below subtracts the originally proposed logarithm when present. Its interval quantifies Monte Carlo uncertainty, not the difference between a finite-size effective exponent and an asymptotic exponent. The interactive page also gives the uncorrected distributions and all intermediate sizes.

{chr(10).join(allrows)}

## Sampler and statistical checks

All heights are real. Every lattice pair is included, together with the entire infinite zero exterior. We use the ordered-pair Hamiltonian from the numerical specification and β = 1. There is no range cutoff, no integer rounding, and no energy resampling used to enforce a check.

A Metropolis sweep contains 2n+1 random-site proposals, four interval proposals and two smooth collective proposals. Proposal scales adapt only during warmup and are then frozen. The cluster sampler adds two embedded-Ising reflection clusters to each sweep. A seed and a reflection plane are selected; a pair with positive reflection cost Δ is joined with probability 1 − exp(−βΔ). The fixed exterior is a ghost vertex, and a cluster attached to that vertex is left unchanged. The plane displacement has a symmetric density about the seed height, which is unchanged by the reverse reflection. Together with the bond probabilities, this gives detailed balance for the same real-valued Gibbs law, including q &lt; 1.

The native sampler passed independent local and block energy-difference checks and single-site generalized-normal checks at all four q values. The cluster sampler was checked against exact finite Gaussian covariances at n = 16, α = 1.75 and 3.5, using 40,000 recordings per check. The three checked projection variances agreed within about 1.3%.

Homogeneity gives the independent exact identity βH ∼ Gamma((2n+1)/q, 1). Across displayed cells, q E[H]/(2n+1) lies in {ci(audit['qEnergyMeanRange'])}, and q Var(H)/(2n+1) lies in {ci(audit['qEnergyVarianceRange'])}; both should equal 1. Exact Gaussian covariances were computed separately by Cholesky solution of the full finite precision matrix 4L.

Across 35 displayed quadratic cells, the mean measured/exact even-bump variance ratio is {fmt(audit['gaussianMeanVarianceRatio'])}. The approximate 95% variance intervals contain the exact answer in {audit['gaussianVarianceCoverage95']} of 35 cells, and the kurtosis intervals contain zero in {audit['gaussianKurtosisCoverage95']} of 35 cells. We report this coverage rather than forcing every control to pass: the intervals are pointwise, and occasional misses are expected when many cells are inspected.

We report conventional split R̂ for both the observable and its square; effective sample estimates for the observable, its square and its fourth power; independent-chain traces; and stratified block-bootstrap intervals. The primary bootstrap uses 1,000 resamples of blocks of 500 retained recordings. Sensitivity intervals use blocks of 250 and 1,000 recordings. The square and fourth-power diagnostics matter because ordinary mean ESS can look adequate while tail estimates remain noisy. The plots flag cells with R̂ ≥ 1.01 or fewer than 1,000 effective samples in one of the three displayed smooth projections. Every flagged cell remains visible.

All inferences are exploratory. The original parameter grid and conjectures were saved before running it; the subsequent extensions and their reasons are preserved separately. The intervals are not simultaneous across all 28 pairs. Persistent fourth cumulants favor a non-Gaussian limit, while finite-size positive kurtosis alone does not distinguish persistence from a slow decay to zero.

## Reproduce the sweep

Download the source archive and the per-pair ZIPs from the [data page](data.html#parameter-sweep), preserving their paths. Raw CSV values are stored at full printed precision. On this machine the samplers were compiled with clang++; the Gaussian reference uses macOS Accelerate.

```bash
mkdir -p .verification
clang++ -O3 -march=native -ffast-math -std=c++17 sweep-sos.cpp -o .verification/sweep-sos
clang++ -O3 -march=native -ffast-math -std=c++17 cluster-sos.cpp -o .verification/cluster-sos
.verification/sweep-sos --test
python3 run-parameter-sweep.py
python3 run-sweep-extensions.py
python3 run-sweep-extensions.py --rough-high --workers 3
python3 run-sweep-extensions.py --precision --workers 3
node analyze-parameter-sweep.cjs
node audit-parameter-sweep.cjs
```

Extract the plans-and-checks archive as well to supply the exact covariance references. The original q = 1, α = 2.25 study through n = 2048 is preserved in the [earlier detailed report](results.html). Its data have not been replaced by the parameter sweep.
'''
(root/'sweep-report.md').write_text(text)
print(json.dumps({'report':'sweep-report.md','recordings':s['totalGeneratedRecordings'],'cells':s['completedCells']}))
