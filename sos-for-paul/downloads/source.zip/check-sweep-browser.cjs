'use strict';
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),assert=require('node:assert/strict');
const {spawn}=require('node:child_process'),{pathToFileURL}=require('node:url');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'sos-sweep-browser-'));
 const chrome=spawn('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',['--headless','--no-first-run','--no-default-browser-check','--remote-debugging-port=0','--remote-debugging-address=127.0.0.1','--user-data-dir='+profile,'about:blank'],{stdio:'ignore'});let ws;
 try{
  const portFile=path.join(profile,'DevToolsActivePort');for(let i=0;i<150&&!fs.existsSync(portFile);i++)await sleep(100);
  const port=Number(fs.readFileSync(portFile,'utf8').split('\n')[0]),tabs=await(await fetch('http://127.0.0.1:'+port+'/json/list')).json();
  ws=new WebSocket(tabs.find(t=>t.type==='page').webSocketDebuggerUrl);await new Promise((resolve,reject)=>{ws.onopen=resolve;ws.onerror=reject;});
  let id=0;const pending=new Map(),errors=[];ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p.reject(m.error):p.resolve(m.result);}else if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails);};
  const call=(method,params={})=>new Promise((resolve,reject)=>{const i=++id;pending.set(i,{resolve,reject});ws.send(JSON.stringify({id:i,method,params}));});
  const evaluate=async expression=>{const result=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(result.exceptionDetails)throw Error(result.exceptionDetails.exception?.description||result.exceptionDetails.text);return result.result.value;};
  await call('Runtime.enable');await call('Page.enable');await call('Emulation.setDeviceMetricsOverride',{width:1440,height:1100,deviceScaleFactor:1,mobile:false});
  const url=process.env.SOS_SWEEP_URL||pathToFileURL(path.resolve('parameter-sweep.html')).href;await call('Page.navigate',{url});
  for(let i=0;i<300;i++){if(await evaluate('Boolean(window.SWEEP_UI)'))break;await sleep(100);}
  assert.equal(await evaluate('window.PARAMETER_SWEEP.pairs.length'),28);assert.equal(await evaluate('document.querySelectorAll("#sweep-all-table tr").length'),28);
  const buttons=await evaluate('Array.from(document.querySelectorAll("#sweep-all-table button:first-child")).map(b=>b.dataset.pair)');
  for(const key of [...new Set(buttons)]){
   await evaluate('document.querySelector('+JSON.stringify('[data-pair="'+key+'"]')+').click()');
   assert.equal(await evaluate('window.SWEEP_UI.selected.key'),key);
   assert.ok(await evaluate('document.querySelectorAll("#sweep-size-table tr").length >= 3'));
   assert.ok(await evaluate('Array.from(document.querySelectorAll("canvas")).every(c=>c.width>100 && c.height>100)'));
  }
  await evaluate('document.querySelector('+JSON.stringify('[data-pair="q0.5-a2.125"]')+').click();window.scrollTo(0,0)');await sleep(200);
  fs.writeFileSync('.verification/sweep-desktop.png',Buffer.from((await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false})).data,'base64'));
  const before=await evaluate('document.getElementById("sweep-histogram").toDataURL()');
  await evaluate('document.getElementById("sweep-projection").value="g";document.getElementById("sweep-projection").dispatchEvent(new Event("change"))');
  assert.notEqual(await evaluate('document.getElementById("sweep-histogram").toDataURL()'),before);
  await evaluate('document.getElementById("sweep-n").value="32";document.getElementById("sweep-n").dispatchEvent(new Event("change"))');
  assert.equal(await evaluate('window.SWEEP_UI.selected.N'),32);
  await call('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});await evaluate('window.scrollTo(0,0)');await sleep(300);
  assert.ok(await evaluate('document.documentElement.scrollWidth<=391'));
  fs.writeFileSync('.verification/sweep-mobile.png',Buffer.from((await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false})).data,'base64'));
  assert.equal(errors.length,0,JSON.stringify(errors));
  const report={passed:true,url,pairs:28,checks:'All parameter selectors and size tables; six canvases; projection and size changes; mobile layout; no browser exceptions'};
  fs.writeFileSync('.verification/sweep-browser-checks.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));
 }finally{ws?.close();chrome.kill();setTimeout(()=>fs.rmSync(profile,{recursive:true,force:true}),300);}
})().catch(e=>{console.error(e);process.exitCode=1;});
