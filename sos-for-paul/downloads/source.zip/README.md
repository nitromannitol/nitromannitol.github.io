# Long-range interface lab

Open **[gaussianity.html](gaussianity.html)** for the real-valued q = 1, α = 2.25 experiment, now with saved runs through n = 2048, fitted marginal curves and joint-law diagnostics. Read **[scaling-limit-guess.md](scaling-limit-guess.md)** for the current numerical hypothesis, uncertainty and reproduction commands. The working guess is a non-Gaussian field with amplitude exponent 1/4; its precise law remains unidentified.

The website also displays an interactive conjectural phase diagram in q and α, including logarithmic normalizations, the exact quadratic line, and a proposed cutoff construction of the non-Gaussian field. **[precise-conjectures.md](precise-conjectures.md)** states the hypotheses. The **[parameter sweep](parameter-sweep.html)** tests 28 pairs; **[sweep-report.md](sweep-report.md)** gives the updated evidence and reproduction commands. The particular continuum cutoff construction remains untested.

The latest compiled runs contribute 264,000 recorded configurations at n = 128, 256, 512, 1024 and 2048. The page retains earlier small sizes for 456,000 recordings altogether. Raw data are in `real-sos-results.json` and `real-sos-results.csv`; additional projections and signed increments are in `experiments/native/`. The earlier continuation is documented in **continuation-results.md** and archived as `experiments/continuation-256.*`.

The earlier **index.html** remains an integer-valued comparison. Both pages work without a server, installation, account, or internet connection.

- `2412.15782.pdf` — downloaded 45-page paper, arXiv v2.
- `2412.15782.txt` — full text extracted with `pdftotext -layout`.
- `paper-notes.md` — main results, proof strategy, numerical derivation and limitations.
- `index.html`, `app.js`, `model.js` — interactive simulation and numerical core.
- `test-model.cjs` — numerical verification; run with `node test-model.cjs`.

Choose a preset or edit α, β, q and N, then select **Apply & restart**. Use Pause, Step, CSV export, and the optional size experiment. Sampling settings expose the seed, warmup and thinning. Changing parameters clears the previous run and size experiment.

All interactions, including the infinite zero-height exterior, are included through numerically evaluated power-law tails. Both q-SOS and the integer Gaussian case q = 2 are sampled using symmetric Metropolis moves. Details are in the reading notes and the expandable section of the HTML page.

Downloaded PDF SHA-256:

    4ada18b45337608c2e3faf38ef3d25e8616fb4401ea6a9ad3f5402e66b296189
