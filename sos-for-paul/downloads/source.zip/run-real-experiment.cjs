'use strict';
const fs = require('node:fs');
const path = require('node:path');
const R = require('./real-model.js');
const samples = Number(process.env.SOS_SAMPLES || 4000);
const burn = Number(process.env.SOS_BURN || 8000);
const thin = Number(process.env.SOS_THIN || 5);
const sizes = (process.env.SOS_SIZES || '8,16,32,64').split(',').map(Number);
const q = Number(process.env.SOS_Q || 1);
const config = { q, alpha: Number(process.env.SOS_ALPHA || 2.25), beta: Number(process.env.SOS_BETA || 1), seed: Number(process.env.SOS_SEED || 15782) };
const stem = process.env.SOS_OUTPUT || (q===2 ? 'gaussian-benchmark' : 'real-sos-results');
fs.mkdirSync(path.dirname(stem), { recursive: true });
if (!Number.isInteger(samples) || samples < 128 || !Number.isInteger(burn) || burn < 0 || !Number.isInteger(thin) || thin < 1) throw Error('Invalid sampling budget');
const results = [];
const begin = Date.now();
for (const N of sizes) {
  const runs = [];
  for (let replica = 0; replica < 3; replica++) {
    const state = R.runSetup({ ...config, N }, replica);
    const warmup = q === 2 ? 0 : burn, stride = q === 2 ? 1 : thin;
    let energySum = 0, energySquareSum = 0;
    while (state.chain.sweeps < warmup + samples*stride) {
      state.chain.sweep();
      if (state.chain.sweeps > warmup && (state.chain.sweeps-warmup)%stride===0) {
        R.recordRun(state);
        energySum += config.beta * state.chain.energy;
        energySquareSum += (config.beta * state.chain.energy) ** 2;
      }
    }
    state.data.meanBetaEnergyPerDimension = energySum / samples / state.chain.n;
    state.data.varianceBetaEnergyPerDimension = (energySquareSum / samples - (energySum / samples) ** 2) / state.chain.n;
    state.data.finalEnergy = state.chain.energy;
    state.data.finalHeights = Array.from(state.chain.heights);
    state.data.acceptance = Object.fromEntries(Object.keys(state.chain.attempted).map(k=>[k,state.chain.accepted[k]/state.chain.attempted[k]]));
    runs.push(state.data);
    console.log(JSON.stringify({stage:'chain-complete',N,replica:replica+1,seed:state.chain.seed,sweeps:state.chain.sweeps,meanBetaEnergyPerDimension:state.data.meanBetaEnergyPerDimension,seconds:(Date.now()-begin)/1000}));
  }
  const result = R.summarizeRuns(runs, { ...config, N });
  results.push(result);
  fs.writeFileSync(stem+'.checkpoint.json', JSON.stringify({ config, settings:{samples,burn,thin,replicas:3,radius:.8,sizes},results,partial:true }));
  console.log(JSON.stringify({ N, variance: result.f.variance, candidateVariance: result.candidate.variance, userVariance: result.user.variance, excess: result.f.excess, interval: result.kurtosisInterval, rhat: result.rhat, rhatSquared: result.rhatSquared, ess: result.effectiveSamples, essSquared: result.effectiveSquaredSamples, wick: result.wickResidual, seconds: (Date.now()-begin)/1000 }));
}
const output = { config, settings: { samples, burn: q===2?0:burn, thin:q===2?1:thin, replicas:3, radius:.8, sizes }, results, generatedAt:new Date().toISOString(), elapsedSeconds:(Date.now()-begin)/1000 };
fs.writeFileSync(stem+'.json', JSON.stringify(output));
fs.writeFileSync(stem+'.js', 'window.SAVED_REAL_EXPERIMENT = '+JSON.stringify(output)+';\n');
const rows = ['N,q,alpha,beta,replica,seed,sample,raw_f,raw_g,user_observable,candidate_observable,centre'];
for (const result of results) result.runs.forEach((run,r)=>run.f.forEach((x,i)=>rows.push([result.N,config.q,config.alpha,config.beta,r+1,run.seed,i+1,x,run.g[i],x/result.N**result.user.exponent,x*(result.candidate.factor??result.N**(-result.candidate.exponent)),run.centre[i]].join(','))));
fs.writeFileSync(stem+'.csv', rows.join('\n')+'\n');
