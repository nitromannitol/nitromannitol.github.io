'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const root='experiments/parameter-sweep',s=JSON.parse(fs.readFileSync(root+'/summary.json'));
assert.equal(s.pairs.length,28);assert.equal(s.completedCells,140);assert.equal(s.totalGeneratedChains,531);assert.equal(s.totalGeneratedRecordings,4344000);assert.equal(s.configurations,3456000);
const controls=[],energy=[],mixing=[];
for(const p of s.pairs){
 const cells=s.results.filter(c=>c.key===p.key);assert.deepEqual(cells.map(c=>c.N),[32,64,128,256,512]);
 for(const c of cells){
  assert.equal(c.chains.length,3);assert.equal(new Set(c.chains.map(r=>r.seed)).size,3);
  assert.ok(Math.abs(c.stats.f.excess-c.joint.fExcess)<1e-9);
  assert.ok(Math.abs(c.stats.g.excess-c.joint.gExcess)<1e-9);
  assert.ok(Math.abs(c.stats.f.variance/c.joint.variance-1)<1e-9);
  assert.ok(Math.abs(c.energy.qMeanPerDimension-1)<.015,`${c.key},${c.N}: energy mean`);
  assert.ok(Math.abs(c.energy.qVariancePerDimension-1)<.13,`${c.key},${c.N}: energy variance`);
  assert.ok(c.energy.maxEnergyDrift<1e-6);
  energy.push(c.energy);if(!c.quality.adequate)mixing.push({key:c.key,N:c.N,...c.quality});
  if(c.q===2){assert.ok(c.gaussianControl);const g=c.gaussianControl;controls.push({key:c.key,N:c.N,ratio:g.varianceRatio,interval:g.varianceRatioInterval,varianceCovered:g.varianceRatioInterval[0]<=1&&g.varianceRatioInterval[1]>=1,kurtosis:c.stats.f.excess,kurtosisInterval:c.bootstrap.intervals.fExcess,kurtosisCovered:c.bootstrap.intervals.fExcess[0]<=0&&c.bootstrap.intervals.fExcess[1]>=0,adequate:c.quality.adequate});}
 }
}
assert.equal(controls.length,35);
const mean=controls.reduce((a,c)=>a+c.ratio,0)/controls.length;
assert.ok(Math.abs(mean-1)<.04,'Aggregate Gaussian variance agreement');
const report={passed:true,configurations:s.configurations,totalGeneratedRecordings:s.totalGeneratedRecordings,totalGeneratedChains:s.totalGeneratedChains,completedCells:s.completedCells,
  qEnergyMeanRange:[Math.min(...energy.map(e=>e.qMeanPerDimension)),Math.max(...energy.map(e=>e.qMeanPerDimension))],qEnergyVarianceRange:[Math.min(...energy.map(e=>e.qVariancePerDimension)),Math.max(...energy.map(e=>e.qVariancePerDimension))],
  gaussianControls:controls,gaussianMeanVarianceRatio:mean,gaussianVarianceCoverage95:controls.filter(c=>c.varianceCovered).length,gaussianKurtosisCoverage95:controls.filter(c=>c.kurtosisCovered).length,
  cellsFlaggedByMixingScreen:mixing,notes:'Coverage is reported, not forced to 100%. The intervals are pointwise. All original slow chains remain archived; this audit concerns the displayed cells.'};
fs.writeFileSync(root+'/audit.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
