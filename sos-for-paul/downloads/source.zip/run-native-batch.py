"""Run independent compiled chains, retaining per-chain data and progress."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import json
import subprocess
import time

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'experiments' / 'native'
OUT.mkdir(exist_ok=True)
jobs = [(n, r) for n in (2048, 1024, 512, 256, 128) for r in range(3)]
start = time.time()

def run(job):
    n, replica = job
    large = n == 2048
    seed = (2213701 if large else 913701) + 104729 * (replica + 1) + 1009 * n
    stem = OUT / f'n{n}-r{replica}'
    args = [str(ROOT / '.verification' / 'native-sos'), str(n), '8000' if large else '20000', '20000', '5', str(seed), str(replica), str(stem), '48' if large else '24']
    with (stem.with_suffix('.log')).open('w') as log:
        result = subprocess.run(args, stdout=log, stderr=subprocess.STDOUT, cwd=ROOT)
    if result.returncode:
        raise RuntimeError(f'Failed n={n}, chain={replica}: {stem}.log')
    meta = json.loads(stem.with_suffix('.meta.json').read_text())
    print(json.dumps({'complete': True, 'N': n, 'replica': replica, 'seconds': round(time.time()-start, 1), 'meanEnergyPerDimension': meta['meanBetaEnergyPerDimension'], 'acceptance': meta['acceptance']}), flush=True)
    return meta

with ThreadPoolExecutor(max_workers=6) as pool:
    futures = [pool.submit(run, job) for job in jobs]
    metadata = [future.result() for future in as_completed(futures)]
(OUT/'batch.json').write_text(json.dumps({'sampler':'native-sos.cpp','samplesPerChainBySize':{str(n):8000 if n==2048 else 20000 for n in (128,256,512,1024,2048)},'warmup':20000,'thin':5,'jobs':metadata,'seconds':time.time()-start}, indent=2))
