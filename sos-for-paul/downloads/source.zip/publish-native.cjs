'use strict';
const fs=require('node:fs');
const archive='experiments/continuation-256';
if(!fs.existsSync(archive+'.json')){
  const previous=JSON.parse(fs.readFileSync('real-sos-results.json'));
  if(previous.results.some(r=>r.N>256))throw Error('Expected the original continuation before creating its archive.');
  for(const ext of ['json','js','csv'])fs.copyFileSync('real-sos-results.'+ext,archive+'.'+ext);
}
const previous=JSON.parse(fs.readFileSync(archive+'.json'));
const native=JSON.parse(fs.readFileSync('experiments/native-results-slim.json'));
const comparison=JSON.parse(fs.readFileSync('experiments/limit-comparison.json'));
const results=[...previous.results.filter(r=>r.N<128),...native.results.map(r=>{
  const joint=comparison.analysis.find(c=>c.N===r.N).joint;
  return {...r,originalKurtosisInterval:r.kurtosisInterval,kurtosisInterval:joint.intervals.evenExcess,bootstrapBlockLength:joint.blockLength,bootstrap:{repetitions:joint.repetitions,stratifiedByChain:true},sampler:'native-sos.cpp'};
})].sort((a,b)=>a.N-b.N);
for(const r of results){
  if(r.runs.length!==3||r.runs.reduce((s,run)=>s+run.f.length,0)!==r.f.count)throw Error('Incomplete saved runs at n='+r.N);
}
const settings={...native.settings,sizes:results.map(r=>r.N),mixedBudgets:true,samplesPerChainBySize:Object.fromEntries(results.map(r=>[r.N,r.runs[0].f.length]))};
const data={config:native.config,settings,results,generatedAt:new Date().toISOString(),complete:true,sourceFiles:[archive+'.json','experiments/native-results-slim.json','experiments/limit-comparison.json'],notes:'Seeds and sampling budgets are recorded per chain. New native runs replace n=128 and n=256; old runs remain archived. Full extra projections, signed increments and point values are in experiments/native-results.json and per-chain CSVs.'};
fs.writeFileSync('real-sos-results.json',JSON.stringify(data));
fs.writeFileSync('real-sos-results.js','window.SAVED_REAL_EXPERIMENT = '+JSON.stringify(data)+';\n');
const fd=fs.openSync('real-sos-results.csv','w');
fs.writeSync(fd,'N,q,alpha,beta,replica,seed,sample,raw_f,raw_g,user_observable,candidate_observable,centre\n');
for(const r of results)for(let k=0;k<r.runs.length;k++){
  const run=r.runs[k],rows=run.f.map((f,i)=>[r.N,r.config.q,r.config.alpha,r.config.beta,k+1,run.seed,i+1,f,run.g[i],f/r.N**r.user.exponent,f*(r.candidate.factor??r.N**(-r.candidate.exponent)),run.centre[i]].join(','));
  fs.writeSync(fd,rows.join('\n')+'\n');
}
fs.closeSync(fd);
const largest=results.slice(-3);
const H=.25+.5*Math.log(largest.at(-1).candidate.variance/largest[0].candidate.variance)/Math.log(largest.at(-1).N/largest[0].N);
console.log(JSON.stringify({published:true,sizes:settings.sizes,recordedConfigurations:results.reduce((s,r)=>s+r.f.count,0),largeSizePairingExponent:H,largest:largest.map(r=>({N:r.N,excess:r.f.excess,interval:r.kurtosisInterval,variance:r.candidate.variance,ess:r.effectiveSamples,essSquared:r.effectiveSquaredSamples,rhat:r.rhat}))},null,2));
