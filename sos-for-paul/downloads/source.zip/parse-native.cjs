'use strict';
const fs=require('node:fs'),path=require('node:path');
const R=require('./real-model.js');
const sizes=(process.env.SOS_NATIVE_SIZES||'128,256,512,1024,2048').split(',').map(Number);
const results=[];
for(const N of sizes){
  const stems=Array.from({length:3},(_,r)=>`experiments/native/n${N}-r${r}`);
  if(!stems.every(s=>fs.existsSync(s+'.meta.json')))continue;
  const runs=stems.map(stem=>{
    const meta=JSON.parse(fs.readFileSync(stem+'.meta.json'));
    const lines=fs.readFileSync(stem+'.csv','utf8').trim().split('\n'),head=lines.shift().split(',');
    const columns=Object.fromEntries(head.map(h=>[h,[]]));
    for(const line of lines){const row=line.split(',').map(Number);row.forEach((v,i)=>columns[head[i]].push(v));}
    if(columns.f.length!==meta.samples)throw Error('Incomplete native CSV');
    return {...meta,f:columns.f,g:columns.g,centre:columns.centre,extra:{left:columns.left,right:columns.right,narrow:columns.narrow},points:Array.from({length:9},(_,i)=>columns['p'+i]),increments:meta.lags.map(lag=>columns['inc'+lag]),energySamples:columns.energy};
  });
  const config={N,q:1,alpha:2.25,beta:1,seed:N===2048?2213701:913701};
  const summary=R.summarizeRuns(runs,config);
  results.push(summary);
  console.log(JSON.stringify({N,excess:summary.f.excess,oddExcess:summary.g.excess,interval:summary.kurtosisInterval,rhat:summary.rhat,rhatSquared:summary.rhatSquared,rhatG:summary.rhatG,ess:summary.effectiveSamples,essSquared:summary.effectiveSquaredSamples,candidateVariance:summary.candidate.variance,wick:summary.wickResidual,acceptance:runs.map(r=>r.acceptance)}));
}
const output={config:{q:1,alpha:2.25,beta:1,seed:913701},settings:{samples:20000,burn:20000,thin:5,replicas:3,radius:.8,sizes:results.map(r=>r.N),mixedBudgets:results.some(r=>r.runs[0].samples!==20000),samplesPerChainBySize:Object.fromEntries(results.map(r=>[r.N,r.runs[0].samples]))},results,sampler:'native-sos.cpp',complete:results.length===sizes.length,generatedAt:new Date().toISOString()};
fs.writeFileSync('experiments/native-results.json',JSON.stringify(output));
const slim={...output,results:results.map(r=>({...r,runs:r.runs.map(run=>{const {extra,points,increments,energySamples,...keep}=run;return keep;})}))};
fs.writeFileSync('experiments/native-results-slim.json',JSON.stringify(slim));
