// Finite Dirichlet Gaussian covariance at alpha_eff=2.5, hence candidate H=1/4.
#define main native_sampler_main
#include "native-sos.cpp"
#undef main
#include <Accelerate/Accelerate.h>
int main(int argc,char**argv){
  int N=argc>1?std::stoi(argv[1]):1024;Chain c(N,2.5,1,1);int m=c.m,k=14,info=0;
  Vec A(size_t(m)*m),rhs(size_t(m)*k),original;
  for(int i=0;i<m;i++)for(int j=0;j<m;j++)A[i+size_t(j)*m]=i==j?2*tail(2.5,1):-c.w[std::abs(i-j)];
  for(int j=0;j<5;j++)for(int i=0;i<m;i++)rhs[i+size_t(j)*m]=c.functions[j][i];
  for(int j=0;j<9;j++)rhs[N+int(std::round(N*(-.8+.2*j)))+size_t(j+5)*m]=1;
  original=rhs;char lower='L';
  dpotrf_(&lower,&m,A.data(),&m,&info);if(info){std::cerr<<"Cholesky error "<<info;return 1;}
  dpotrs_(&lower,&m,&k,A.data(),&m,rhs.data(),&m,&info);if(info)return 1;
  std::cout<<std::setprecision(17)<<"{\"N\":"<<N<<",\"alpha\":2.5,\"q\":2,\"beta\":1,\"covariance\":[";
  for(int i=0;i<k;i++){if(i)std::cout<<',';std::cout<<'[';for(int j=0;j<k;j++){if(j)std::cout<<',';double v=0;for(int r=0;r<m;r++)v+=original[r+size_t(i)*m]*rhs[r+size_t(j)*m];std::cout<<v/4;}std::cout<<']';}std::cout<<"]}\n";
}
