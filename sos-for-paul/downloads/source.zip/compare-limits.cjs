'use strict';
const fs=require('node:fs');const R=require('./real-model.js');const {randomGenerator}=require('./model.js');
const input=JSON.parse(fs.readFileSync('experiments/native-results.json'));
const keys=['f','g','left','right','narrow'];
const get=(run,key)=>key==='f'||key==='g'?run[key]:run.extra[key];
const average=x=>x.reduce((s,v)=>s+v,0)/x.length;
function logGamma(z){
  const p=[676.5203681218851,-1259.1392167224028,771.3234287776531,-176.6150291621406,12.507343278686905,-.13857109526572012,9.984369578019572e-6,1.5056327351493116e-7];
  if(z<.5)return Math.log(Math.PI)-Math.log(Math.sin(Math.PI*z))-logGamma(1-z);
  z--;let x=.9999999999998099;for(let i=0;i<p.length;i++)x+=p[i]/(z+i+1);const t=z+7.5;
  return .5*Math.log(2*Math.PI)+(z+.5)*Math.log(t)-t+Math.log(x);
}
function golden(fn,a,b,iterations=32){const ratio=(Math.sqrt(5)-1)/2;let c=b-ratio*(b-a),d=a+ratio*(b-a),fc=fn(c),fd=fn(d);for(let i=0;i<iterations;i++){if(fc<fd){b=d;d=c;fd=fc;c=b-ratio*(b-a);fc=fn(c);}else{a=c;c=d;fc=fd;d=a+ratio*(b-a);fd=fn(d);}}return (a+b)/2;}
function ggFit(values){
  const logs=values.map(x=>Math.log(Math.max(1e-300,Math.abs(x))));
  const scale=p=>Math.pow(p*average(logs.map(x=>Math.exp(p*x))),1/p);
  const loss=p=>-Math.log(p)+Math.log(2*scale(p))+logGamma(1/p)+1/p;
  const p=golden(loss,1,2.5),a=scale(p);
  return {shape:p,scale:a,logDensity:x=>Math.log(p)-Math.log(2*a)-logGamma(1/p)-Math.pow(Math.abs(x)/a,p)};
}
function vgFit(values){
  const ts=[.5,1,1.5,2,2.5,3,3.5];const cf=ts.map(t=>average(values.map(x=>Math.cos(t*x))));
  const loss=logk=>{const k=Math.exp(logk);return ts.reduce((s,t,i)=>s+(Math.pow(1+t*t/(2*k),-k)-cf[i])**2,0);};
  const k=Math.exp(golden(loss,0,Math.log(300)));
  const nodes=[],weights=[],left=-12,right=4;let steps=Math.ceil((right-left)/Math.min(.025,.25/Math.sqrt(k)));if(steps%2)steps++;
  const dl=(right-left)/steps,constant=k*Math.log(k)-logGamma(k)-.5*Math.log(2*Math.PI);
  for(let i=0;i<=steps;i++){const l=left+i*dl,v=Math.exp(l);nodes.push(1/(2*v));weights.push(dl/3*(i===0||i===steps?1:i%2?4:2)*Math.exp(constant+(k-.5)*l-k*v));}
  const exactLog=x=>{let density=0;for(let i=0;i<nodes.length;i++)density+=weights[i]*Math.exp(-nodes[i]*x*x);return Math.log(density);};
  const grid=Array.from({length:1001},(_,i)=>exactLog(i/100));
  const logDensity=x=>{x=Math.abs(x);if(x>=10)return exactLog(x);const i=Math.floor(100*x),p=x*100-i;return grid[i]*(1-p)+grid[i+1]*p;};
  return {shape:k,excess:3/k,logDensity,cf:t=>Math.pow(1+t*t/(2*k),-k)};
}
function standardized(values){const m=R.moments(values),sd=Math.sqrt(m.variance);return {values:values.map(x=>(x-m.mean)/sd),mean:m.mean,sd};}
function predictiveFits(r,key){
  const folds=[];
  for(let held=0;held<r.runs.length;held++){
    const train=standardized(r.runs.flatMap((run,i)=>i===held?[]:get(run,key)));
    const test=get(r.runs[held],key).map(x=>(x-train.mean)/train.sd),gg=ggFit(train.values),vg=vgFit(train.values);
    const gaussian=x=>-.5*Math.log(2*Math.PI)-x*x/2;
    folds.push({heldChain:held,ggShape:gg.shape,vgShape:vg.shape,ggLogGain:average(test.map(x=>gg.logDensity(x)-gaussian(x))),vgLogGain:average(test.map(x=>vg.logDensity(x)-gaussian(x)))});
  }
  const pooled=standardized(r.runs.flatMap(run=>get(run,key))).values,gg=ggFit(pooled),vg=vgFit(pooled);
  const density=Array.from({length:161},(_,i)=>{const x=-4+i*.05;return {x,gaussian:Math.exp(-x*x/2)/Math.sqrt(2*Math.PI),generalizedNormal:Math.exp(gg.logDensity(x)),varianceGamma:Math.exp(vg.logDensity(x))};});
  const cf=Array.from({length:13},(_,i)=>{const t=i*.25;return {t,empirical:average(pooled.map(x=>Math.cos(t*x))),gaussian:Math.exp(-t*t/2),varianceGamma:vg.cf(t)};});
  return {key,ggShape:gg.shape,vgShape:vg.shape,ggLogGain:average(folds.map(x=>x.ggLogGain)),vgLogGain:average(folds.map(x=>x.vgLogGain)),folds,density,cf};
}
function jointMetrics(s){
  const n=s[0],mx=s[1]/n,my=s[2]/n,vx=s[3]/n-mx*mx,vy=s[4]/n-my*my,c=s[5]/n-mx*my;
  const kx=(s[8]/n-4*mx*s[6]/n+6*mx*mx*s[3]/n-3*mx**4)/vx**2-3;
  const ky=(s[9]/n-4*my*s[7]/n+6*my*my*s[4]/n-3*my**4)/vy**2-3;
  const mixed=s[12]/n-2*mx*s[11]/n-2*my*s[10]/n+4*mx*my*s[5]/n+mx*mx*s[4]/n+my*my*s[3]/n-3*mx*mx*my*my;
  const rho=c/Math.sqrt(vx*vy),wick=(mixed-vx*vy-2*c*c)/(vx*vy),common=3*wick/(1+2*rho*rho);
  return {evenExcess:kx,oddExcess:ky,difference:kx-ky,wick,commonPrediction:common,evenMinusCommon:kx-common,oddMinusCommon:ky-common};
}
function jointBootstrap(r,blockLength=512,repetitions=1000){
  const xs=standardized(r.runs.flatMap(x=>x.f)),ys=standardized(r.runs.flatMap(x=>x.g));
  const groups=r.runs.map(run=>{const blocks=[];for(let i=0;i+blockLength<=run.f.length;i+=blockLength){const sums=Array(13).fill(0);for(let j=i;j<i+blockLength;j++){const x=(run.f[j]-xs.mean)/xs.sd,y=(run.g[j]-ys.mean)/ys.sd;const row=[1,x,y,x*x,y*y,x*y,x**3,y**3,x**4,y**4,x*x*y,x*y*y,x*x*y*y];for(let k=0;k<13;k++)sums[k]+=row[k];}blocks.push(sums);}return blocks;});
  const rng=randomGenerator(r.N+721883),distribution=[];
  for(let b=0;b<repetitions;b++){const sums=Array(13).fill(0);for(const group of groups)for(let i=0;i<group.length;i++){const row=group[Math.floor(rng()*group.length)];for(let k=0;k<13;k++)sums[k]+=row[k];}distribution.push(jointMetrics(sums));}
  const intervals={};for(const key of Object.keys(distribution[0])){const x=distribution.map(d=>d[key]).sort((a,b)=>a-b);intervals[key]=[x[Math.floor(.025*x.length)],x[Math.floor(.975*x.length)]];}
  return {blockLength,repetitions,intervals};
}
function correlation(x,y){const mx=average(x),my=average(y);let xx=0,yy=0,xy=0;for(let i=0;i<x.length;i++){const a=x[i]-mx,b=y[i]-my;xx+=a*a;yy+=b*b;xy+=a*b;}return xy/Math.sqrt(xx*yy);}
function covariance(x,y){const mx=average(x),my=average(y);return x.reduce((s,v,i)=>s+(v-mx)*(y[i]-my),0)/x.length;}
const analysis=[];
for(const r of input.results){
  const functionStats=keys.map(key=>({key,...R.moments(r.runs.flatMap(run=>get(run,key)))}));
  const joint=jointBootstrap(r);
  const increments=r.runs[0].lags.map((lag,i)=>{
    const x=r.runs.flatMap(run=>run.increments[i]);const out={lag,relative:lag/r.N,...R.moments(x)};
    if(lag===r.N/16){const chains=r.runs.map(run=>run.increments[i]);out.rhat=R.splitRhat(chains);out.rhatSquared=R.splitRhat(chains,true);out.effectiveSamples=chains.reduce((sum,chain)=>sum+R.effectiveSamples(chain),0);}
    if(i+1<r.runs[0].lags.length){const y=r.runs.flatMap(run=>run.increments[i+1].map((v,j)=>v-run.increments[i][j]));out.adjacentCorrelation=correlation(x,y);out.adjacentVarianceRatio=R.moments(y).variance/out.variance;}
    return out;
  });
  const fields=keys.map(key=>r.runs.flatMap(run=>get(run,key)));
  const covarianceMatrix=fields.map(x=>fields.map(y=>covariance(x,y)));
  const correlationMatrix=fields.map(x=>fields.map(y=>correlation(x,y)));
  const pointFields=Array.from({length:9},(_,i)=>r.runs.flatMap(run=>run.points[i]));
  const pointCovariance=pointFields.map(x=>pointFields.map(y=>covariance(x,y)));
  const fits=(r.N>=512?['f','g','narrow']:['f']).map(key=>predictiveFits(r,key));
  const out={N:r.N,functionStats,joint,increments,covarianceMatrix,correlationMatrix,pointCovariance,positions:r.runs[0].positions.map(i=>(i-r.N)/r.N),fits};
  analysis.push(out);
  console.log(JSON.stringify({N:r.N,even:r.f.excess,odd:r.g.excess,intervals:joint.intervals,fits:fits.map(f=>({key:f.key,ggShape:f.ggShape,vgShape:f.vgShape,ggLogGain:f.ggLogGain,vgLogGain:f.vgLogGain})),bulkIncrement:increments.find(x=>x.lag===r.N/16)}));
}
fs.writeFileSync('experiments/limit-comparison.json',JSON.stringify({config:input.config,analysis,gaussianAdjacentCorrelation:Math.pow(2,-.5)-1},null,2));
// Expose the smooth model curves without shipping extra raw data to the browser.
fs.writeFileSync('limit-comparison.js','window.LIMIT_COMPARISON = '+JSON.stringify({config:input.config,analysis})+';\n');
