# Scaling-limit experiment: current guess

The parameter-dependent phase diagram and a precise constructive candidate for the joint limiting law are now in [precise-conjectures.md](precise-conjectures.md) and displayed directly on [gaussianity.html](gaussianity.html). The report below describes the evidence at the simulated point q = 1, α = 2.25; the other nonlinear parameter regimes and the cutoff construction have not been tested by these data.

For **real heights, q = 1, α = 2.25**, my current guess is a **non-Gaussian continuum field with amplitude exponent H = 1/4**. Ordinary fractional Brownian motion is less consistent with the simulated smooth observables. A more specific hypothesis worth investigating is a centered Gaussian field conditional on a **nontrivial random covariance**, whose randomness cannot be represented by a single independent scalar amplitude. The covariance mixing law has not been identified. This is a numerical conjecture, and a slow crossover to Gaussian behavior remains possible.

The latest simulations reach **n = 2048**, or 4097 real heights, with three independently seeded chains at every size. Open [gaussianity.html](gaussianity.html) for the saved distributions, fitted curves, joint diagnostics and size comparisons. All calculations here used local files; no further web research was used.

## What is being rescaled

The domain is −n,…,n, with height zero on the entire exterior. At β = 1 the sampled density is proportional to exp(−H), where

    H(φ) = 2 Σ_{−n≤i<j≤n} |φ(i)−φ(j)| / |i−j|^2.25
           + 2 Σ_{i=−n}^n b_i |φ(i)|,
    b_i = Σ_{j outside [−n,n]} |i−j|^(−2.25).

All pairs and exterior tails are retained. The factor 2 matches the ordered-pair convention. Heights are continuous; there is no rounding or height cutoff. For this homogeneous real model, changing β only rescales heights by β⁻¹.

The proposed field rescaling is n⁻¹/⁴φ(⌊nt⌋). For a smooth test function, the corresponding pairing is

    A_n(f) = n^(−5/4) Σ_i f(i/n) φ(i).

The extra n⁻¹ is the Riemann-sum factor. The originally requested n⁻¹/² normalization instead has variance growing approximately as n^1.5 in these experiments. Its standardized histogram is identical, so it remains useful for testing shape.

We use f(t) = exp(1 − 1/(1 − (t/0.8)²)) inside |t| < 0.8, and zero outside. The odd function is g(t) = 3(t/0.8)f(t). New runs also record bumps centered at ±0.4 with radius 0.25, a central bump with radius 0.35, nine point heights and signed increments.

## Evidence at the largest sizes

The excess kurtosis is the centered fourth moment divided by variance squared, minus 3; its Gaussian value is zero.

| n | Recorded configurations | Var(A_n(f)) | Even-bump excess kurtosis | Approximate 95% interval | ESS of even bump |
|---|---:|---:|---:|---|---:|
| 512 | 60,000 | 0.02459 | 0.260 | [0.179, 0.346] | 3,137 |
| 1024 | 60,000 | 0.02468 | 0.302 | [0.164, 0.453] | 1,913 |
| 2048 | 24,000 | 0.02407 | 0.442 | [0.261, 0.625] | 514 |

The raw-pairing variance fit over these three sizes gives H ≈ 0.242. The near stability of Var(A_n(f)) supports H = 1/4 as a working exponent. Positive kurtosis persists over this range instead of visibly approaching zero. At n = 1024, about 0.44% of centered standardized samples exceed three standard deviations in absolute value; a Gaussian gives about 0.27%.

The n = 2048 estimate has a wider interval and fewer effective samples. Its larger point estimate should not be read as proof that kurtosis increases with n. These observations support a non-Gaussian guess but do not establish convergence or tightness.

## Testing a simple candidate joint law

Suppose the proposed limit were Φ = A G, with one scalar random amplitude A **independent** of a centered Gaussian field G. Every nonzero smooth pairing would then have the same standardized excess kurtosis. There is a second restriction: writing X = ⟨Φ,f⟩, Y = ⟨Φ,g⟩, ρ = Corr(X,Y), and

    W = [E(X²Y²) − E(X²)E(Y²) − 2E(XY)²] / [Var(X)Var(Y)],

for centered variables, the model predicts κ_X = κ_Y = 3W/(1 + 2ρ²).

At n = 1024, κ_X = 0.302 and κ_Y = 0.099. The jointly resampled interval for κ_X − κ_Y is **[0.052, 0.377]**. The interval for κ_Y − 3W/(1 + 2ρ²) is **[−0.410, −0.156]**. Both argue against that simple joint law at this size. The n = 512 results give the same direction of evidence. At n = 2048 these differences have wider intervals that include zero, so the largest run alone is inconclusive about this refinement.

The finite q = 1 model has a Gaussian covariance-mixture representation: its Laplace interaction factors can be expressed as positive mixtures of quadratic factors. That motivates testing whether covariance randomness persists under rescaling. The experiments suggest that it might, with different random effects on different spatial modes. They do not identify a limiting random operator or an exact distribution for its covariance.

## Marginal fits and covariance

A generalized-normal density proportional to exp(−|x/a|^p) fits the even bump with p ≈ 1.81, 1.79 and 1.73 at n = 512, 1024 and 2048; p = 2 is Gaussian. A variance-gamma marginal, obtained by Gaussian variance mixing with a Gamma variable, gives a similarly good approximation. Training on two chains and evaluating on the third gives small positive average log-score gains over a fitted Gaussian, roughly 0.001–0.003 nats per recorded sample for the even bump.

These are descriptive marginal approximations. Their fitted parameters vary with observable and size; neither fit supplies a consistent joint field law. The HTML can overlay either density on the histogram.

At n = 1024, adjacent increments of length n/16 have correlation −0.317, compared with −0.293 for unconditioned H = 1/4 fBm. The fixed zero exterior affects covariance. At n = 2048 this increment has only about 229 effective samples and split R-hat 1.012, so its estimated correlation is particularly uncertain. Covariance matching therefore remains unresolved.

An additional exact quadratic covariance calculation at n = 1024 uses q = 2, α = 2.5, which has the candidate exponent H = 1/4. It is saved in `experiments/gaussian-reference-n1024.json`. This differs from the same-α Gaussian sampler control: matching H requires changing α for the quadratic model. Neither covariance comparison overrides the nonzero fourth cumulants.

## Sampling, uncertainty and checks

The compiled sampler uses the same full Hamiltonian as the JavaScript sampler, with continuous local, interval and smooth collective Metropolis proposals. Proposal amplitudes are symmetric and independent of the current state. The six collective directions are the constant profile and the five smooth functions above. Their larger fixed proposal scales improve exploration of coarse modes without changing the target density.

Each size has three chains starting at negative-bump, zero and positive-bump profiles. Each chain receives 20,000 warmup sweeps, followed by one recording every five sweeps. Sizes 128, 256, 512 and 1024 have 20,000 recordings per chain; n = 2048 has 8,000 per chain. The native runs contribute **264,000 recorded configurations**. The HTML also retains the earlier n = 8, 16, 32 and 64 runs, for **456,000 total**. Recorded configurations within a chain are correlated.

For the new runs, reported intervals use 1,000 bootstrap replicates of nonoverlapping blocks of 512 recordings, resampled separately within each chain. Incomplete final blocks are omitted from resampling. Joint resampling preserves simultaneous f and g observations and recomputes centering. These nominal 95% intervals account approximately for sampling dependence, but not finite-size error or undetected slow mixing. Multiple comparisons are not adjusted.

At n = 1024 the even-bump split R-hat is 1.0004; at n = 2048 it is 1.0056. The corresponding squared-observable R-hat values are 1.0004 and 1.0010, with squared-observable ESS about 6461 and 2307. These are traditional variance-based diagnostics, not rank-normalized R-hat. They cannot certify equilibration.

Energy differences were checked against full recomputation, and the single-site real model was checked against its exact Laplace law. Across all new chains, mean energy per dimension is within 0.14% of its exact value 1, and final accumulated energy discrepancies are below 1.6 × 10⁻¹¹. The exact energy identity follows from homogeneity: H has a Gamma(2n+1,1) distribution at β = 1. Earlier exact Gaussian controls are retained in [continuation-results.md](continuation-results.md).

Per-chain energy checks, moments and early/late comparisons are in `experiments/native-audit.json`. Signed increments, all five projections and point values are preserved in `experiments/native-results.json` and the CSVs under `experiments/native/`. The HTML export retains the even/odd traces, center heights, final profiles, seeds and sampling metadata. The earlier continuation through n = 256 is archived as `experiments/continuation-256.*`.

## Reproduce

From this directory, these commands reproduce the compiled runs and update the local HTML data. Running the batch replaces the corresponding native output files.

```sh
clang++ -O3 -march=native -ffast-math -std=c++17 native-sos.cpp -o .verification/native-sos
.verification/native-sos --test
python3 run-native-batch.py
node parse-native.cjs
node compare-limits.cjs
node publish-native.cjs
SOS_BROWSER_SAVED_ONLY=1 node check-real-browser.cjs
open gaussianity.html
```

For n ≤ 1024 the seed is 913701 + 104729(replica+1) + 1009n and the smooth proposal multiplier is 24. For n = 2048 the seed base is 2213701 and the multiplier is 48. Replica indices are 0, 1 and 2. These are explicitly recorded in each native metadata file. Compiler and platform differences can change seeded trajectories through floating-point acceptance decisions.
